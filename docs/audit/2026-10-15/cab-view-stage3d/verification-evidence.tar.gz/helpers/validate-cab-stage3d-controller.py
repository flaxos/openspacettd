"""Exercise diagnostic guards against copies of the single real native manifest."""
import copy,hashlib,importlib.util,json,sys
from pathlib import Path
root=Path(__file__).parent/'openspacettd-cabview';sys.path.insert(0,str(root/'scripts'))
spec=importlib.util.spec_from_file_location('cab_gate_controller',root/'scripts/test_cab_view_gate_native.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
run=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();assert not out.exists()
original_path=run/'cold/gate-native-manifest.json';original=json.loads(original_path.read_text())
original_sha256=hashlib.sha256(original_path.read_bytes()).hexdigest()
checks={'real_cold':m.validate_stage3d(original,'cold',run/'cold'),
        'real_roundtrip':m.validate_stage3d(json.loads((run/'roundtrip/gate-native-manifest.json').read_text()),'roundtrip',run/'roundtrip')}
assert all(c['passed'] for c in checks.values())
def reject(name,change,phase='cold'):
    v=copy.deepcopy(original);change(v['stage3d_paired']);result=m.validate_stage3d(v,phase,run/'cold');assert not result['passed'],name;checks[name]=result
reject('missing_pair',lambda d:d['pairs'].pop())
reject('duplicate_frame',lambda d:d['pairs'][0]['arms'][1]['frame'].__setitem__('frame_id',d['pairs'][0]['arms'][0]['frame']['frame_id']))
reject('control_runs_reduced',lambda d:d['pairs'][1]['arms'][0].__setitem__('actual_mode','reduced'))
reject('wrong_pair_order',lambda d:d['pairs'][0].__setitem__('label','RO'))
reject('changed_cycle_cache',lambda d:d['cycles'][0]['cache'].__setitem__('effect_scratch_capacity_bytes',1))
reject('adaptive_scale',lambda d:d['pairs'][0]['arms'][0]['frame'].__setitem__('scale',0.8))
reject('image_mismatch',lambda d:d['pairs'][0].__setitem__('pair_images_equal',False))
reject('invalid_palette',lambda d:d['canonical_palette_rgba'][0].__setitem__(0,256))
reject('failed_restore',lambda d:d.__setitem__('palette_restored',False))
reject('diagnostic_in_roundtrip',lambda d:None,'roundtrip')
reject('overlapping_timings',lambda d:d['pairs'][0]['arms'][1].__setitem__('relative_start_us',d['pairs'][0]['arms'][0]['relative_start_us']+1))
reject('negative_stage',lambda d:d['pairs'][0]['arms'][1]['frame'].__setitem__('effect_us',-1))
reject('missing_cycle',lambda d:d['cycles'].pop())
reject('reused_representative_file',lambda d:d['representative_images'].__setitem__('AB',d['representative_images']['OR']))
# Empty Reduced work can round to a microsecond; do not require literal zero.
v=copy.deepcopy(original);v['stage3d_paired']['pairs'][0]['arms'][1]['frame']['effect_us']=1
checks['nonzero_reduced_timer_allowed']=m.validate_stage3d(v,'cold',run/'cold');assert checks['nonzero_reduced_timer_allowed']['passed']
assert hashlib.sha256(original_path.read_bytes()).hexdigest()==original_sha256
record={'passed':True,'real_reports_accepted':2,'malformed_copies_rejected':14,'nonzero_reduced_timer_allowed':True,
        'original_manifest_sha256':hashlib.sha256(original_path.read_bytes()).hexdigest(),'checks':checks}
out.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='checks'}))
