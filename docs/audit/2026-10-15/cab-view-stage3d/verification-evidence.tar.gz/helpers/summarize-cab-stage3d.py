"""Report the one declared paired diagnostic; never convert it into acceptance."""
import hashlib,json,math,statistics,sys
from pathlib import Path
root=Path(__file__).parent/'openspacettd-cabview'
run=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();assert not out.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((run/'gate-runner-evidence.json').read_text());assert report['passed']
manifest_path=run/'cold/gate-native-manifest.json'
d=json.loads(manifest_path.read_text())['stage3d_paired']
assert len(d['pairs'])==200 and d['completed_cycles']==50
stages=('prepare_us','raster_us','effect_us','output_us','total_us')
def distribution(values):
    values=sorted(values);assert values
    return {'n':len(values),'min':values[0],'median':statistics.median(values),'p95':values[math.ceil(.95*len(values))-1],'max':values[-1]}
def measurements(arms):
    return {'wall_us':distribution([a['wall_us'] for a in arms]),**{s:distribution([a['frame'][s] for a in arms]) for s in stages}}
labels={x:[] for x in 'ORAB'};raw=[];by_order={x:[] for x in ('OR','AB','RO','BA')}
for i,p in enumerate(d['pairs']):
    first,second=p['arms'];order=p['label'];assert order in by_order
    arms={a['label']:a for a in p['arms']}
    positive,negative=('R','O') if order in ('OR','RO') else ('B','A')
    delta={'wall_us':arms[positive]['wall_us']-arms[negative]['wall_us'],
           **{s:arms[positive]['frame'][s]-arms[negative]['frame'][s] for s in stages}}
    position_delta={'wall_us':second['wall_us']-first['wall_us'],
                    **{s:second['frame'][s]-first['frame'][s] for s in stages}}
    gap=second['relative_start_us']-first['relative_start_us']-first['wall_us'];assert gap>=0
    entry={'pair_index':i,'cycle':p['cycle'],'position':p['position'],'order':order,
           'contrast':f'{positive}-{negative}','signed_difference_us':delta,
           'second_minus_first_us':position_delta,'intermember_gap_us':gap,
           'arms':p['arms']}
    by_order[order].append(entry);raw.append(entry)
    for a in p['arms']:labels[a['label']].append(a)
assert {k:len(v) for k,v in labels.items()}=={k:100 for k in labels}
label_stats={k:measurements(v) for k,v in labels.items()}
order_stats={}
for k,ps in by_order.items():
    order_stats[k]={'pairs':len(ps),'signed_difference_us':{s:distribution([p['signed_difference_us'][s] for p in ps]) for s in ('wall_us',)+stages},
                    'second_minus_first_us':{s:distribution([p['second_minus_first_us'][s] for p in ps]) for s in ('wall_us',)+stages},
                    'intermember_gap_us':distribution([p['intermember_gap_us'] for p in ps])}
arm_stats={}
for arm,orders in (('experimental',('OR','RO')),('negative_control',('AB','BA'))):
    ps=[p for p in raw if p['order'] in orders]
    arm_stats[arm]={'pairs':len(ps),'signed_difference_us':{s:distribution([p['signed_difference_us'][s] for p in ps]) for s in ('wall_us',)+stages},
                    'second_minus_first_us':{s:distribution([p['second_minus_first_us'][s] for p in ps]) for s in ('wall_us',)+stages},
                    'intermember_gap_us':distribution([p['intermember_gap_us'] for p in ps])}
# Correlated tails retain both members and every existing stage on the same frame.
tails={}
for label in labels:
    selected=sorted((p for p in raw if any(a['label']==label for a in p['arms'])),
                    key=lambda p:next(a['wall_us'] for a in p['arms'] if a['label']==label),reverse=True)[:6]
    tails[label]=selected
old_path=root/'build/cab-stage3c-candidate/diagnostic-01/cold/gate-native-manifest.json'
old=json.loads(old_path.read_text())['stage3c_diagnostic']['timing']
image_paths=[run/'cold'/p for p in d['representative_images'].values()]
old_image=old_path.parent/old['blocks'][0]['image']
identity={k:d[k]==old[k] for k in ('pose','frozen_snapshot','canonical_palette_rgba','scene_effect','effect_elapsed_ms','view_width','view_height')}
identity['scene_cache']=d['warm_cache']==old['blocks'][0]['cache']
identity['all_images_exact_stage3c']=all(sha(p)==sha(old_image) for p in image_paths)
assert all(identity.values()),identity
original_delta=label_stats['R']['wall_us']['p95']-label_stats['O']['wall_us']['p95']
control_delta=label_stats['B']['wall_us']['p95']-label_stats['A']['wall_us']['p95']
summary={'scope':'One declared same-context diagnostic; not a new acceptance matrix or causal proof.',
         'native_report_sha256':sha(run/'gate-runner-evidence.json'),'native_manifest_sha256':sha(manifest_path),
         'source_binary_sha256':report['phases'][1]['binary_sha256'],
         'schedule':{'warmup_off':20,'warmup_reduced':20,'cycles':50,'pairs':200,'frames':400,
                     'even':['OR','AB','RO','BA'],'odd':['BA','RO','AB','OR']},
         'labels':{'O':'experimental physical Off','R':'experimental physical Reduced','A':'control physical Off','B':'control physical Off'},
         'label_distributions':label_stats,'order_distributions':order_stats,'arm_distributions':arm_stats,
         'original_style_metric':{'definition':'nearest-rank p95(R)-p95(O), experimental 100+100 samples only',
                                  'added_p95_us':original_delta,'unchanged_allowance_us':500,
                                  'within_allowance_this_diagnostic_only':original_delta<=500,
                                  'median_difference_us':label_stats['R']['wall_us']['median']-label_stats['O']['wall_us']['median']},
         'negative_control_metric':{'definition':'nearest-rank p95(B)-p95(A), both physically Off','added_p95_us':control_delta},
         'historical_identity':identity,'images':{p.name:sha(p) for p in image_paths},
         'retained_prior_results':{'stage3b_original_failed_median_added_p95_us':1114,'stage3b_later_matrix_median_added_p95_us':-313,
                                   'stage3c_diagnostic_added_p95_us':671,'unchanged_allowance_us':500},
         'correlated_tail_pairs':tails,'raw_chronological_pairs':raw,
         'limits':['No rerun or threshold adjustment; this diagnostic cannot replace the retained failures.',
                   'Preallocated image capture still perturbs the next member; actual gap is retained, never subtracted.',
                   'A difference of marginal percentiles is not the percentile of paired differences; both are named separately.',
                   'Stage percentiles are descriptive; attribution must use same-frame correlated stages and differential source.',
                   'No per-frame allocation, CPU-frequency or thread-scheduling attribution is available.']}
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ('original_style_metric','negative_control_metric','historical_identity')}))
print(json.dumps({k:v['wall_us'] for k,v in label_stats.items()}))
print(json.dumps({k:{'wall':v['signed_difference_us']['wall_us'],'position':v['second_minus_first_us']['wall_us'],'gap':v['intermember_gap_us']} for k,v in order_stats.items()}))
