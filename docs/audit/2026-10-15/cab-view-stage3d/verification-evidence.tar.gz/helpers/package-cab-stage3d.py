"""Seal only Stage3D evidence, preserving prior checkpoints and owner state."""
import hashlib,json,shutil,tarfile
from pathlib import Path
root=Path(__file__).parent/'openspacettd-cabview';audit=root/'docs/audit/2026-10-15/cab-view-stage3d'
archive=audit/'verification-evidence.tar.gz';assert not archive.exists();minimum=100*1024*1024
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
entries=[]
for p in sorted((root/'build/cab-stage3d-candidate').rglob('*')):
    if p.is_file() and not p.is_symlink() and 'profile' not in p.relative_to(root/'build/cab-stage3d-candidate').parts and p.suffix in ('.json','.gz','.log','.png','.ppm','.sav','.cfg','.scr','.patch'):
        entries.append((p,'candidate/'+str(p.relative_to(root/'build/cab-stage3d-candidate'))))
for name in ('source-before-stage3d.json','source-before-stage3d.tar.gz'):
    entries.append((root/'build/cab-stage3d-baseline'/name,'baseline/'+name))
for p in sorted((root/'build/agent-logs').glob('stage3d-*')):
    if p.is_file() and p.suffix in ('.json','.log'):entries.append((p,'logs/'+p.name))
for name in ('run-cab-stage2-build.py','run-cab-stage2-regressions.py','record-cab-stage3b-source.py','record-cab-stage3d-build.py','summarize-cab-stage3d.py','validate-cab-stage3d-controller.py','package-cab-stage3d.py','prepare-cab-gate-native-fixture.py','cab-view-stage3d-start.json'):
    entries.append((root.parent/name,'helpers/'+name))
for name in ('docs/ACTIVE_EXECUTION_PLAN.md','scripts/test_cab_view_gate_native.py','scripts/test_commonwealth_platform_art.py','build/CMakeCache.txt','build/compile_commands.json','build/cab-gate-native/fixture-01/cab-gate-depot-fixture.sav'):
    entries.append((root/name,'reproduction/'+name))
for name in ('cold/gate-native-manifest.json','cold/stage3c_block_0.ppm'):
    source=root/'build/cab-stage3c-candidate/diagnostic-01'/name
    if source.is_file(): entries.append((source,'historical/stage3c/'+name))
manifest={};seen={};links=0
with tarfile.open(archive,'x:gz',compresslevel=6) as target:
    for path,name in entries:
        assert shutil.disk_usage(root).free>=minimum and name not in manifest
        info={'bytes':path.stat().st_size,'sha256':sha(path)};manifest[name]=info;key=(info['sha256'],info['bytes'])
        member=target.gettarinfo(str(path),arcname=name)
        if key in seen:
            member.type=tarfile.LNKTYPE;member.linkname=seen[key];member.size=0;target.addfile(member);links+=1
        else:
            seen[key]=name
            with path.open('rb') as data:target.addfile(member,data)
record={'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'logical_files':len(manifest),'unique_payloads':len(seen),'identical_content_hardlinks':links,'members':manifest}
(audit/'archive-manifest.json').write_text(json.dumps(record,indent=2)+'\n')
verified={};regular=hardlinks=0
with tarfile.open(archive,'r|gz') as source:
    for member in source:
        expected=manifest[member.name]
        if member.islnk():
            assert member.linkname in verified and verified[member.linkname]==expected;hardlinks+=1
        else:
            assert member.isfile() and member.size==expected['bytes'];h=hashlib.sha256();data=source.extractfile(member)
            for chunk in iter(lambda:data.read(1024*1024),b''):h.update(chunk)
            assert h.hexdigest()==expected['sha256'],member.name;regular+=1
        verified[member.name]=expected
assert set(verified)==set(manifest)
(audit/'archive-verification.json').write_text(json.dumps({'passed':True,'archive_sha256':record['archive_sha256'],'logical_files_verified':len(verified),'regular_payloads_hashed':regular,'hardlink_targets_verified':hardlinks},indent=2)+'\n')
v=json.loads((audit/'verification.json').read_text());v['archive']={k:record[k] for k in record if k!='members'};v['archive']['file']=archive.name;(audit/'verification.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps(v['archive']))
