import json,shlex,subprocess,sys,time,hashlib
from pathlib import Path
root=Path('/workspace/openspacettd');out=root/'build/agent-logs/a1-windows-macros';source=root/'src/portal/connected_economy.cpp'
wrapper=out/'translation-unit.cpp'
wrapper.write_text(f'#include "{root}/src/stdafx.h"\n#define near\n#define far\n#include "{source}"\n')
line=next(line for line in (root/'build/agent-logs/a1-connected-compile-commands.txt').read_text().splitlines() if line.endswith(str(source)))
cmd=shlex.split(line);skip={'-o','-MT','-MF'};fixed=[];i=0
while i<len(cmd):
 if cmd[i] in skip:i+=2;continue
 if cmd[i] in ('-c','-MD') or cmd[i]==str(source):i+=1;continue
 fixed.append(cmd[i]);i+=1
fixed+=['-fsyntax-only',str(wrapper)]
phase=sys.argv[1];log=out/f'{phase}.log';start=time.time()
with log.open('w') as stream:code=subprocess.call(fixed,cwd=root/'build',stdout=stream,stderr=subprocess.STDOUT)
r={'phase':phase,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'command':fixed,'exit_code':code,'seconds':round(time.time()-start,2),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'wrapper_sha256':hashlib.sha256(wrapper.read_bytes()).hexdigest(),'windows_macro_source':'https://raw.githubusercontent.com/microsoft/win32metadata/main/generation/WinSDK/RecompiledIdlHeaders/shared/minwindef.h','include_chain':['connected_economy.cpp','network/network_base.h','network/core/address.h','network/core/os_abstraction.h','winsock2.h/windows.h','minwindef.h'],'local_compiler':'GCC/Linux with observed Windows empty near/far macros; not an MSVC replacement'}
(out/f'{phase}.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r),flush=True)
raise SystemExit(0 if ((phase=='before' and code!=0) or (phase=='after' and code==0)) else 1)
