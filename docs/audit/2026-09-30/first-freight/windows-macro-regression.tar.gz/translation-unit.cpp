#include "/workspace/openspacettd/src/stdafx.h"
#define near
#define far
#include "/workspace/openspacettd/src/portal/connected_economy.cpp"
