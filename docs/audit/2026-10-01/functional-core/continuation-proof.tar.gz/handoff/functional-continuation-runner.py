#!/usr/bin/env python3
"""One explicitly authorized repaired load of the existing funded checkpoint."""
import hashlib
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/workspace/openspacettd')
sys.path.insert(0, str(ROOT / 'scripts'))
from test_integrated_economy import acceptance_inputs, audit
from test_wp11_slice import OfflineEngine, require
from test_commonwealth_platform_art import environment, profile_environment

HEAD = '5d729abe87500446c43c4a1c5ca68c08c8e323ca'
AUDIT = ROOT / 'docs/audit/2026-10-01/functional-core'
LOGS = ROOT / 'build/agent-logs'
OUTPUT = LOGS / 'functional-core-continuation'
handoff = json.loads((AUDIT / 'continuation-handoff.json').read_text())
prior_path = LOGS / 'functional-core-handoff-3/evidence.json'
prior = json.loads(prior_path.read_text())
primary = prior['primary']
checkpoint = ROOT / handoff['checkpoint']['path']
expected_path = AUDIT / 'completed-state.json'
expected = json.loads(expected_path.read_text())
hash_file = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD,
        'Continuation requires the exact authorized head')
require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip(),
        'Continuation requires a clean source checkout')
manifest = json.loads((AUDIT / 'handoff-3-manifest.json').read_text())
require(hash_file(prior_path) == manifest['archive_members']['campaign/evidence.json']['sha256'],
        'Preserved failing campaign evidence changed')
require(hash_file(checkpoint) == 'a5fe2b1e85f4ca5c3cb1be0352af253dfa7ffa04b94df5cf768e5230a14a7945',
        'Only the original completed checkpoint is authorized')
require(hash_file(expected_path) == handoff['checkpoint']['expected_state_sha256'] and
        expected == [row for row in primary['trace'] if row['operation'] == 'functional-budget-off'][-1]['result']['state'],
        'Expected state must be the original pre-second-load state')
gate = manifest['corrected_source_gates']
require(hash_file(ROOT / 'build/openttd') == gate['binary_sha256'], 'Reviewed corrected-source binary changed')
for name, sha in gate['source_files_sha256'].items():
    require(hash_file(ROOT / name) == sha, f'Reviewed executable source changed: {name}')
require(primary['status'] == 'FAIL' and primary['error'] == 'Second cold load changed retained unlock/custody/cash/orders' and
        primary['advance_counts'] == {'initial': 82, 'cold': 1}, 'Prior hard stop or carried advances changed')
require(primary['financial_reconciliation']['assistance'] == 6000000 and
        primary['financial_reconciliation']['campaign_gross_debit_cap_usage'] == 2762347 and
        expected['tick'] == 120064 and expected['money'] == 3620714 and expected['loan'] == 100000 and
        expected['research'] == [[0, 0, 0, [301]]], 'Funded checkpoint/cumulative accounting changed')
stop = datetime.fromisoformat('2026-10-01T01:39:59.143032+00:00')
remaining = (stop - datetime.now(timezone.utc)).total_seconds()
require(remaining > 0, 'Original cold phase already expired; continuation NOT RUN')
deadline = time.monotonic() + remaining
OUTPUT.mkdir(exist_ok=False)
config = OUTPUT / 'functional.cfg'
config.write_bytes((LOGS / 'functional-core-handoff-3/primary/functional.cfg').read_bytes())
report = {'label': 'ASSISTED FUNCTIONAL', 'status': 'PARTIAL', 'human_uat': 'Pending',
          'ordinary_start_economic_proof': 'NOT RUN', 'authorization': 'NEW explicit same-funded-checkpoint continuation handoff',
          'inputs': acceptance_inputs(ROOT / 'build/openttd'), 'runner_sha256': hash_file(Path(__file__)),
          'checkpoint_sha256': hash_file(checkpoint), 'expected_state_sha256': hash_file(expected_path),
          'prior_evidence_sha256': hash_file(prior_path), 'prior_cold_advances': 1, 'prior_initial_advances': 82,
          'cold_advance_cap_total': 240, 'new_advances': 0, 'cold_stop_utc': stop.isoformat(),
          'absolute_stop_utc': '2026-10-01T02:24:44Z', 'assistance_used_gbp': 6000000, 'assistance_remaining_gbp': 0,
          'grant_commands_issued': 0, 'fresh_games_started': 0, 'confirmation_loads': 0,
          'second_load_equality': 'NOT RUN', 'continuation': 'NOT RUN', 'replay': 'NOT RUN',
          'trace': [], 'native_transactions': [], 'started_at_utc': datetime.now(timezone.utc).isoformat()}
receipts = 0
debits = 0
engine = None


def persist():
    report['artifacts'] = {p.name: hash_file(p) for p in OUTPUT.glob('*.sav')}
    (OUTPUT / 'evidence.json').write_text(json.dumps(report, indent=2) + '\n')


def state():
    return json.loads(engine.command('connected_economy functional-status', 'CONNECTED functional-state '))


def paid_visits():
    samples = [entry['result'] for entry in report['trace']]
    arrivals = sorted(row for sample in samples for row in sample['audit']['arrivals'] if row[1] == 4 and row[2] == 3)
    delivered, booked = set(), set()
    for sample in samples:
        for row in sample['audit']['payments']:
            earlier = [a[0] for a in arrivals if a[0] <= row[0]]
            if row[1] == 4 and row[2] == 3 and row[3] == 33 and row[4] > 0 and row[5] > 0 and earlier:
                delivered.add(max(earlier))
        for row in sample['audit']['cash_payments']:
            earlier = [a[0] for a in arrivals if a[0] <= row[0]]
            if row[1] == 4 and row[2] == 3 and row[3] > 0 and earlier:
                booked.add(max(earlier))
    return sorted(delivered & booked)


def consuming_months():
    return sorted({row[0] for entry in report['trace'] for row in entry['result']['audit']['city_months']
                   if row[1] == 0 and row[2] > 0})


try:
    report['confirmation_loads'] = 1
    persist()
    with environment(profile_environment(OUTPUT)):
        engine = OfflineEngine(ROOT / 'build/openttd', config, OUTPUT, 'repaired-second', save=checkpoint, deadline=deadline)
    engine.deadline = deadline
    loaded = state()
    report['loaded_state'] = loaded
    report['second_load_equal'] = loaded == expected
    report['second_load_equality'] = 'PASS' if loaded == expected else 'FAIL'
    persist()
    require(loaded == expected, 'Repaired second cold load still differs from exact saved state')
    print('ASSISTED FUNCTIONAL checkpoint: repaired second cold load EXACT equality PASS; no grant; carrying one used cold advance', flush=True)
    previous = loaded
    while not paid_visits() or not consuming_months():
        require(report['new_advances'] < 239 and time.monotonic() < deadline and datetime.now(timezone.utc) < stop,
                'Original shared cold tick/wall bound exhausted')
        before = state()
        report['new_advances'] += 1
        value = json.loads(engine.command('connected_economy functional-advance', 'CONNECTED functional-result '))
        report['trace'].append({'operation': 'functional-advance', 'result': value})
        entries = value['audit']['cash_transactions']
        report['native_transactions'].extend(entries)
        receipts += sum(max(-row[2], 0) for row in entries)
        debits += sum(max(row[2], 0) for row in entries)
        after = value['state']
        require(value['cash_conserved'] and not value['cargo_errors'], 'Continuation cash/cargo mismatch')
        require(after['tick'] - previous['tick'] == 2048, 'Continuation advance differs from 2048 ticks')
        require(sum(row[2] for row in entries) == value['audit']['cash_debits'] and
                after['money'] == before['money'] - sum(row[2] for row in entries), 'Continuation transaction reconciliation failed')
        require(not any(row[1] == 12 and row[2] == -6000000 for row in entries), 'Unexpected further assistance')
        require(after['loan'] == 100000 and after['money'] > 0 and after['research'] == [[0, 0, 0, [301]]],
                'Continuation debt/cash/unlock/project/budget invariant failed')
        require(not any(t['lost'] or t['crashed'] for t in after['trains']), 'Continuation lost/crashed train')
        require(2762347 + debits <= 4000000, 'Original aggregate gross-debit cap exhausted')
        require(after['money'] == 3620714 + receipts - debits, 'Continuation cumulative cash reconciliation failed')
        previous = after
    report['paid_food_visits'] = paid_visits()
    report['consuming_months'] = consuming_months()
    report['continuation'] = 'PASS'
    report['final_state'] = state()
    report['final_audit'] = audit(engine)
    require(state() == report['final_state'], 'Final terrain/text audit changed paused state')
    engine.save(OUTPUT / 'owner-observation.sav')
    report['status'] = 'PASS'
    print('ASSISTED FUNCTIONAL checkpoint: remaining paid FOOD delivery/consuming month and final audit PASS; no extra assistance', flush=True)
except BaseException as error:
    report['error'] = str(error)
    report['status'] = 'PARTIAL' if any(word in str(error) for word in ('bound exhausted', 'wall limit', 'cap exhausted')) else 'FAIL'
    if engine is not None and engine.process.poll() is None and time.monotonic() < deadline:
        try:
            report['stopped_state'] = state()
            engine.save(OUTPUT / 'stopped-partial.sav')
        except Exception as capture_error:
            report['capture_error'] = str(capture_error)
    raise
finally:
    observed = report.get('final_state', report.get('stopped_state', previous if 'previous' in globals() else report.get('loaded_state', {})))
    report['financial_reconciliation'] = {'starting_cash': 100000, 'assistance': 6000000,
        'prior_primary_receipts': 278252, 'new_receipts': receipts, 'total_primary_receipts': 278252 + receipts,
        'prior_primary_debits': 2757538, 'new_debits': debits, 'total_primary_debits': 2757538 + debits,
        'disposable_control_debits': 4809, 'aggregate_gross_debit_usage': 2762347 + debits,
        'ending_cash': observed.get('money'), 'debt': observed.get('loan'),
        'expected_ending_cash': 100000 + 6000000 + 278252 + receipts - 2757538 - debits,
        'remaining_gross_headroom': 1237653 - debits}
    report['aggregate_cold_advances_used'] = 1 + report['new_advances']
    report['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    if engine is not None:
        engine.close()
    persist()
