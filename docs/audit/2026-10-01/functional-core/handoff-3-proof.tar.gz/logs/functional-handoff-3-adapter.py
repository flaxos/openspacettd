#!/usr/bin/env python3
"""Carry two frozen startup failures into the newly authorized exact-head run.

Only the prior-attempt metadata and evidence attachment differ from the pinned
runner. Native/gameplay code, first-failure handling and all limits are unchanged.
"""
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/workspace/openspacettd')
HEAD = '60bc9536c17ece4cd09ebcaecb35df7c2002f53c'
AUDIT = ROOT / 'docs/audit/2026-10-01/functional-core'
LOGS = ROOT / 'build/agent-logs'


def demand(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_frozen(path, expected):
    demand(digest(path) == expected, f'Preserved evidence changed: {path}')
    return json.loads(path.read_text())


demand(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD,
       'New handoff requires the corrected exact head')
demand(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip(),
       'New handoff requires pristine source checkout')
manifest = json.loads((AUDIT / 'recovery-manifest.json').read_text())
first_path = LOGS / 'functional-core-primary/evidence.json'
second_path = LOGS / 'functional-core-recovery/evidence.json'
first = read_frozen(first_path, manifest['original_custody']['failed_evidence_sha256'])
second = read_frozen(second_path, manifest['archive_members']['campaign/evidence.json']['sha256'])
for previous in (first, second):
    primary = previous['primary']
    demand(previous['label'] == 'ASSISTED FUNCTIONAL' and previous['status'] == 'FAIL', 'Prior failure label/status changed')
    demand(not primary['assistance'] and not primary['native_transactions'] and not primary['trace'] and
           not primary['samples'] and primary['advance_counts'] == {'initial': 0, 'cold': 0} and
           all(v == 'NOT RUN' for v in primary['phases'].values()) and
           not any(k in primary for k in ('pristine', 'partial_state', 'construction', 'final', 'preflight')),
           'Prior assistance, gameplay or search cannot be reset')
demand(first['primary']['error'] == 'Timed out waiting for FUNCTIONAL_OFFLINE_START' and not first['artifacts'],
       'Original startup failure changed')
demand(second['primary']['error'] == 'Engine exited while waiting for CONNECTED functional-state ; see log',
       'Second startup failure changed')
demand(second['startup_recovery']['prior_startup_attempts'] == 1 and
       second['startup_recovery']['recovery_startup_attempts'] == 1 and
       manifest['recovery']['total_startup_attempts_consumed'] == 2 and
       manifest['recovery']['total_active_preflight_seconds_for_next_handoff'] == 64 and
       manifest['assistance']['applied_across_both_attempts_gbp'] == 0,
       'Aggregate prior bounds do not match the explicit handoff')
for relative, expected in second['artifacts'].items():
    demand(relative == 'primary/crash20260930233242.sav' and digest(second_path.parent / relative) == expected,
           'Only the frozen diagnostic crash save is allowed in the second failure')
demand(manifest['recovery']['crash_save_is_proof_checkpoint'] is False,
       'Crash save is diagnostic, never pristine')
demand(digest(AUDIT / 'native-proof.tar.gz') == manifest['original_custody']['archive_sha256'] and
       digest(AUDIT / 'recovery-proof.tar.gz') == manifest['recovery_archive']['sha256'],
       'Original failure archives changed')
for relative, expected in manifest['corrected_source_gate_provenance']['source_sha256'].items():
    demand(digest(ROOT / relative) == expected, f'Corrected executable source changed: {relative}')

runner_path = ROOT / 'scripts/test_integrated_economy.py'
original = runner_path.read_text()
modified = original
changes = {
    "'prior_startup_attempts': 1, 'recovery_startup_attempts': 0":
        "'prior_startup_attempts': 2, 'recovery_startup_attempts': 0",
    "'authorization': 'Explicit parent recovery handoff: one canonical startup confirmation'":
        "'authorization': 'NEW explicit execution handoff: one canonical seed11 startup after two preserved failures'",
    "report['total_cash_allowance'] = 6000000":
        "report['execution_handoff'] = EXECUTION_HANDOFF_CONTEXT\n    report['total_cash_allowance'] = 6000000",
}
for before, after in changes.items():
    demand(modified.count(before) == 1, 'Exact-head metadata adapter anchor changed')
    modified = modified.replace(before, after)
context = {
    'label': 'ASSISTED FUNCTIONAL',
    'authorization': 'NEW explicit parent execution handoff after diagnosed startup/snapshot repairs',
    'native_source_head': HEAD,
    'prior_startup_attempts': 2,
    'new_startups_authorized': 1,
    'prior_active_preflight_seconds': 64,
    'remaining_active_preflight_seconds': 1736,
    'absolute_stop_utc': '2026-10-01T02:24:44Z',
    'prior_assistance_gbp': 0,
    'total_allowance_gbp': 6000000,
    'prior_gameplay_advances': {'initial': 0, 'cold': 0},
    'prior_search_candidates': 0,
    'prior_gross_debits_gbp': 0,
    'prior_evidence_sha256': [digest(first_path), digest(second_path)],
    'recovery_manifest_sha256': digest(AUDIT / 'recovery-manifest.json'),
    'runner_source_sha256': digest(runner_path),
    'executed_runner_sha256': hashlib.sha256(modified.encode()).hexdigest(),
    'adapter_sha256': digest(Path(__file__)),
    'metadata_replacements': changes,
    'binary_sha256': digest(ROOT / 'build/openttd'),
    'verified_at_utc': datetime.now(timezone.utc).isoformat(),
    'crash_save_loaded': False,
    'gameplay_or_limit_changes': False,
}
context_path = LOGS / 'functional-handoff-3-context.json'
if '--check-only' in sys.argv:
    print(json.dumps(context, indent=2))
    sys.exit(0)
demand(not context_path.exists(), 'One startup only; preserve this handoff context and do not rerun')
with context_path.open('x') as stream:
    stream.write(json.dumps(context, indent=2) + '\n')
sys.path.insert(0, str(ROOT / 'scripts'))
sys.argv = [str(runner_path), '--functional-core', '--seeds', '11',
            '--functional-recovery-from', str(first_path),
            '--functional-campaign-start-utc', '2026-09-30T22:24:44Z',
            '--functional-startup-used-seconds', '64',
            '--output', str(LOGS / 'functional-core-handoff-3')]
exec(compile(modified, str(runner_path), 'exec'),
     {'__name__': '__main__', '__file__': str(runner_path), 'EXECUTION_HANDOFF_CONTEXT': context})
