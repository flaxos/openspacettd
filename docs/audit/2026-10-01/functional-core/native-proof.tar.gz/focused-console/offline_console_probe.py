"""Focused vanilla 64² console transport regression; no functional campaign or grant."""
import os
import queue
import subprocess
import sys
import threading
import time
from pathlib import Path
sys.path.insert(0, str(Path('scripts').resolve()))
from test_wp11_slice import OfflineEngine, ROOT, require
from test_commonwealth_platform_art import profile_environment
out = (ROOT / 'build/agent-logs/offline-console-focused').resolve()
out.mkdir(exist_ok=False)
config = out / 'probe.cfg'
text = (ROOT / 'demo/integrated_economy.cfg').read_text().split('[newgrf]')[0]
text = text.replace('map_x = 10', 'map_x = 6').replace('map_y = 10', 'map_y = 6')
text = text.replace('player_built_economy = true', 'player_built_economy = false').replace('cst_sector = true', 'cst_sector = false')
config.write_text(text + '\n[misc]\nlanguage = english.lng\n')
engine = OfflineEngine.__new__(OfflineEngine)
engine.log = (out / 'transcript.log').open('x')
engine.commands = (out / 'commands.scr').open('x')
engine.stdout_log = (out / 'stdout.log').open('x')
engine.console_path = out / 'native.log'
engine.console_path.touch(exist_ok=False)
engine.pipe = out / 'commands.fifo'
os.mkfifo(engine.pipe, 0o600)
engine.lines = []
engine.queue = queue.Queue()
engine.deadline = time.monotonic() + 60
scripts = out / 'scripts'
scripts.mkdir()
(scripts / 'game_start.scr').write_text(f'script "{engine.console_path}"\necho FOCUSED_OFFLINE_START\nscript\nexec "{engine.pipe}"\n')
engine.process = subprocess.Popen([str(ROOT / 'build/openttd'), '-v', 'sdl', '-s', 'null', '-m', 'null', '-x', '-c', str(config), '-G', '11', '-t', '1950', '-g'], cwd=out, stdin=subprocess.DEVNULL, stdout=engine.stdout_log, stderr=subprocess.STDOUT, env={**os.environ, **profile_environment(out), 'SDL_VIDEODRIVER': 'dummy', 'OPENSPACETTD_WORLD_COUNT': '1'})
threading.Thread(target=engine.read_console, daemon=True).start()
try:
    engine.wait('FOCUSED_OFFLINE_START')
    while True:
        try:
            fd = os.open(engine.pipe, os.O_WRONLY | os.O_NONBLOCK)
            os.set_blocking(fd, True)
            engine.process.stdin = os.fdopen(fd, 'w', buffering=1)
            break
        except OSError:
            require(engine.process.poll() is None and time.monotonic() < engine.deadline, 'Focused native FIFO failed')
            time.sleep(0.02)
    engine.command('echo SHORT_READY', 'SHORT_READY')
    engine.command('echo SECOND_READY', 'SECOND_READY')
finally:
    engine.close()
require(engine.process.returncode == 0, 'Focused native exit failed')
print('PASS: native short startup and command markers flushed through actual OfflineEngine.command framing; 64² vanilla, one world, no cash/cargo/tech grant or campaign retry.')
