#!/usr/bin/env python3
"""Read-only cold-load equality on hash-verified copies of the original A1 saves."""
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, '/workspace/openspacettd/scripts')
from test_integrated_economy import Engine, ROOT, acceptance_inputs, ordinary_config, require

output = ROOT / 'build/generation-retained-1'
output.mkdir(exist_ok=False)
inputs = ROOT / 'build/agent-logs/generation-retained-inputs'
expected_hashes = {
    11: '51ce35b791d419b3b4106a8f63f715bca89ae54f88522997a6295171320b5ce0',
    101: '42f6bdbdc05d0fd99cf729832bc7811e4413be6c87853d3c0e67fd1eacc423af',
    2026: '5ace1f1f3f1627334034a6d2bcff1584282777d91268b7a43f32d2dce519b038',
}
binary = ROOT / 'build/openttd'
report = {'passed': False, 'simulation_advances': 0, 'spending': 0, 'seeds': [], **acceptance_inputs(binary)}
for seed, expected_hash in expected_hashes.items():
    folder = output / str(seed)
    folder.mkdir()
    save = inputs / str(seed) / 'operation.sav'
    before_hash = hashlib.sha256(save.read_bytes()).hexdigest()
    require(before_hash == expected_hash, 'Original checkpoint hash mismatch')
    original = json.loads((inputs / str(seed) / 'evidence.json').read_text())['before_reload']
    config = folder / 'load.cfg'
    config.write_text(ordinary_config(seed))
    engine = None
    row = {'seed': seed, 'passed': False, 'original_sha256': before_hash}
    report['seeds'].append(row)
    try:
        engine = Engine(binary, config, folder, 'readonly-load', save=save, world_count=7, seed=seed)
        state = json.loads(engine.command('connected_economy first-freight-status', 'FREIGHT state '))
        require(state == original, 'Cold-loaded original freight projection changed')
        row['freight_equal'] = True
        native = json.loads(engine.command('connected_economy generation-contract-status', 'CONNECTED generation-state '))
        row['observed'] = native
        require(json.loads(engine.command('connected_economy first-freight-status', 'FREIGHT state ')) == original,
                'Read-only native observations changed the original projection')
        require(native['core_town_valid'] == (seed == 2026), 'Original Core town fact changed')
        if seed == 2026:
            terminal = next(t for t in native['terminals'] if t['head']['tile'] == 207 * 1024 + 765)
            require(terminal['connection'] == 194301 and terminal['join']['tile'] == 193277 and
                    terminal['join']['type'] == 1 and terminal['join']['owner'] == 16 and
                    terminal['join']['tracks'] == 1, 'Original incompatible neutral TrackX join changed')
            row['blocked_join_preserved'] = True
        row['passed'] = True
    except Exception as exc:
        row['failure'] = str(exc)
    finally:
        if engine is not None:
            engine.close()
        row['after_sha256'] = hashlib.sha256(save.read_bytes()).hexdigest()
        require(row['after_sha256'] == before_hash, 'Input checkpoint was rewritten')
        (folder / 'evidence.json').write_text(json.dumps(row, indent=2) + '\n')
        (output / 'evidence.json').write_text(json.dumps(report, indent=2) + '\n')
        print(f'Retained seed {seed}: {"PASS" if row["passed"] else row.get("failure")}', flush=True)
report['passed'] = all(row['passed'] for row in report['seeds'])
(output / 'evidence.json').write_text(json.dumps(report, indent=2) + '\n')
require(report['passed'], 'Read-only retained-save regression failed')
