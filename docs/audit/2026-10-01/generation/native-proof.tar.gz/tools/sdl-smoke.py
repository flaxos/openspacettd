#!/usr/bin/env python3
"""Render the proof Core town and repaired Industrial join from disposable paused saves."""
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, '/workspace/openspacettd/scripts')
from test_integrated_economy import ROOT, acceptance_inputs, ordinary_config, require

output = ROOT / 'build/generation-sdl-1'
output.mkdir(exist_ok=False)
proof = ROOT / 'build/integrated-generation-contract-2'
generation = json.loads((proof / 'evidence.json').read_text())
binary = ROOT / 'build/openttd'
report = {'passed': False, 'human_uat': 'Pending', 'video': 'sdl/dummy', 'resolution': '2560x1389',
          'seconds_per_view': 8, 'views': [], **acceptance_inputs(binary)}
for seed in generation['seeds']:
    original = seed['repetitions'][0]
    saved = proof / str(seed['requested_seed']) / '1/generation-paid.sav'
    before = hashlib.sha256(saved.read_bytes()).hexdigest()
    require(before == original['paid_sha256'], 'Paid proof save hash mismatch')
    town = original['initial']['towns'][0]['tile']
    terminal = next(t for t in original['initial']['terminals'] if t['gate'] == 2 and t['world'] == 1)['connection']
    for name, tile in [('core-town', town), ('industrial-terminal', terminal)]:
        folder = output / str(seed['requested_seed']) / name
        folder.mkdir(parents=True)
        config = folder / 'sdl.cfg'
        config.write_text(ordinary_config(seed['requested_seed']))
        scripts = folder / 'scripts'
        scripts.mkdir()
        command = f'scrollto instant {tile}'
        (scripts / 'game_start.scr').write_text(command + '\necho GENERATION_SDL_VIEW_READY\n')
        log = folder / 'sdl.log'
        with log.open('w') as stream:
            process = subprocess.Popen([str(binary), '-v', 'sdl', '-s', 'null', '-m', 'null', '-x',
                '-c', str(config), '-g', str(saved), '-r', '2560x1389', '-d', 'sl=2,console=4'],
                cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                env={**os.environ, 'SDL_VIDEODRIVER': 'dummy'})
            try:
                time.sleep(8)
                require(process.poll() is None, f'SDL process exited early: {log}')
            finally:
                if process.poll() is None:
                    process.kill()
                process.wait(timeout=10)
        text = log.read_text()
        require('Loading chunk TRAD' in text and f"Executing cmdline: '{command}'" in text, 'SDL did not load and focus the intended native view')
        require(not any(word in text for word in ('Assertion failed', 'NOT_REACHED', 'Crash encountered', 'Tile does not exist')), str(log))
        require(hashlib.sha256(saved.read_bytes()).hexdigest() == before, 'SDL rewrote proof save')
        report['views'].append({'seed': seed['requested_seed'], 'view': name, 'tile': tile, 'save_sha256': before})
        (output / 'evidence.json').write_text(json.dumps(report, indent=2) + '\n')
        print(f"SDL seed {seed['requested_seed']} {name}: PASS", flush=True)
report['passed'] = True
(output / 'evidence.json').write_text(json.dumps(report, indent=2) + '\n')
