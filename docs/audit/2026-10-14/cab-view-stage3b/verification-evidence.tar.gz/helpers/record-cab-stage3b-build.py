import hashlib,json,sys
from pathlib import Path
root=Path(__file__).parent/'openspacettd-cabview'
mode=sys.argv[1]
assert mode in ('off','on')
out=root/f'build/agent-logs/stage3b-final-{mode}-manifest.json'
assert not out.exists()
cache=(root/'build/CMakeCache.txt').read_text()
assert f'WITH_CAB_VIEW:BOOL={mode.upper()}' in cache
commands=json.loads((root/'build/compile_commands.json').read_text())
units=sorted({r['file'] for r in commands if 'cab_view' in Path(r['file']).name})
defs=sorted({r['file'] for r in commands if '-DWITH_CAB_VIEW' in r['command']})
if mode=='off':assert not units and not defs
else:
    assert {'cab_view_3d.cpp','cab_view_gui.cpp','test_cab_view.cpp','test_cab_view_gate_native.cpp','test_cab_view_native.cpp'}.issubset({Path(n).name for n in units})
    assert set(units).issubset(set(defs))
main=[r for r in commands if r['file'].endswith('/openttd.cpp')];assert main
record={'configuration':mode.upper(),'cab_compile_units':units,'feature_definitions':defs,
        'binary_hashes':{n:hashlib.sha256((root/'build'/n).read_bytes()).hexdigest() for n in ('openttd','openttd_test','lang/english.lng')},
        'compiler':'g++13.3.0','build_type':'Release','with_assert_defined':all('-DWITH_ASSERT' in r['command'] for r in main)}
assert record['with_assert_defined']
out.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
