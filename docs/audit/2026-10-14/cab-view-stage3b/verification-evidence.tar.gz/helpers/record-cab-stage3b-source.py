"""Record an immutable local source/build snapshot, without changing the Git index."""
import hashlib,json,subprocess,sys,tarfile
from pathlib import Path
root=Path(__file__).parent/'openspacettd-cabview'
out=Path(sys.argv[1]);out=out if out.is_absolute() else root/out
out.parent.mkdir(parents=True,exist_ok=True)
assert not out.with_suffix('.json').exists() and not out.with_suffix('.tar.gz').exists()
paths=sorted(set([*root.glob('src/cab_view*'),*root.glob('src/tests/test_cab_view*'),root/'src/widgets/cab_view_widget.h',
                 root/'src/tests/CMakeLists.txt',root/'src/CMakeLists.txt',root/'CMakeLists.txt',root/'cmake/Options.cmake',
                 root/'src/lang/english.txt',root/'scripts/test_cab_view_gate_native.py',root/'docs/ACTIVE_EXECUTION_PLAN.md',
                 root/'build/CMakeCache.txt',root/'build/compile_commands.json']))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
   'branch':subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip(),
   'source':{str(p.relative_to(root)):sha(p) for p in paths},
   'binaries':{n:sha(root/'build'/n) for n in ('openttd','openttd_test','lang/english.lng')}}
with tarfile.open(out.with_suffix('.tar.gz'),'w:gz') as tar:
    for p in paths:tar.add(p,arcname=str(p.relative_to(root)))
r['source_archive_sha256']=sha(out.with_suffix('.tar.gz'))
out.with_suffix('.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'snapshot':str(out),'head':r['head'],'binaries':r['binaries']}))
