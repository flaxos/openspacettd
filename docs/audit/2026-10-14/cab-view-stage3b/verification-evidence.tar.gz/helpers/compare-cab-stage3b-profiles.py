"""Matched three-repeat Stage3B native profiles; raw samples remain in source reports."""
import argparse
import hashlib
import json
import math
import statistics
from pathlib import Path


def describe(values):
    v = sorted(values)
    return dict(median_us=statistics.median(v), p95_us=v[math.ceil(len(v)*.95)-1], minimum_us=v[0], maximum_us=v[-1])


def read(path):
    r = json.loads(path.read_text())
    assert r['passed'], path
    cells = {}
    for phase in r['phases']:
        for collection in ('profiles', 'vehicle_profiles'):
            for c in phase['native_manifest'].get(collection, []):
                key = (collection, phase['phase'], c['capture_label'], c['view_width'], c['view_height'], c['mode'])
                assert key not in cells
                cells[key] = dict(wall=describe([s['external_total_us'] for s in c['samples']]),
                    cold_wall_us=c['cold_sample']['external_total_us'], cache=c.get('cache'),
                    pose=c['pose'], diagnostic_camera=c.get('diagnostic_camera'),
                    vehicle_sequence=c.get('vehicle_sequence'), selected_world=c['selected_world'],
                    palette_sha256=hashlib.sha256(json.dumps(c.get('palette_rgba'),sort_keys=True).encode()).hexdigest(),
                    frozen_snapshot=c['frozen_snapshot'],
                    effect=describe([s['renderer']['effect_us'] if s.get('renderer') else s['effect_us'] for s in c['samples']]),
                    stages={field: describe([s['renderer'][field] for s in c['samples']])
                            for field in ('prepare_us','raster_us','output_us','total_us')} if c['phase']=='scene' else None,
                    cached_sample=c.get('cached_sample'))
    return r, cells


p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--baseline-root',type=Path,required=True)
p.add_argument('--candidate-root',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
assert not a.output.exists()
base=[read(a.baseline_root/f'repeat-{i:02d}/gate-runner-evidence.json') for i in (1,2,3)]
cand=[read(a.candidate_root/f'repeat-{i:02d}/gate-runner-evidence.json') for i in (1,2,3)]
keys=set(cand[0][1]); assert all(set(x[1])==keys for x in base+cand)
r=dict(passed_effect_budget=True, off_regression_investigations=[],groups=[],
       baseline_root=str(a.baseline_root),candidate_root=str(a.candidate_root),
       notes=['Median of three matched-repeat deltas and ratios, not a guarantee for each individual run.',
              'Vehicle profiles use an offset private camera at natural paused arrival; actual loaded content is single layer.',
              'Fixed-scale private renderer measurements are not interactive FPS or human comfort evidence.'])
for group in sorted({key[:-1] for key in keys}):
    off=[c[group+('off',)] for _,c in cand]; b=[c[group+('off',)] for _,c in base]
    for x,y in zip(off,b):
        for field in ('pose','diagnostic_camera','vehicle_sequence','selected_world','palette_sha256'):
            assert x[field]==y[field],(group,field)
    delta=[x['wall']['median_us']-y['wall']['median_us'] for x,y in zip(off,b)]
    threshold=max(250,.1*statistics.median(x['wall']['median_us'] for x in b))
    g=dict(collection=group[0],phase=group[1],label=group[2],width=group[3],height=group[4],
           off_baseline_delta_medians_us=delta,off_baseline_delta_median_us=statistics.median(delta),
           off_investigate_threshold_us=threshold,modes={})
    if statistics.median(delta)>threshold:r['off_regression_investigations'].append(list(group))
    for mode in ('off','reduced','full'):
        v=[c[group+(mode,)] for _,c in cand]
        med=[x['wall']['median_us']-y['wall']['median_us'] for x,y in zip(v,off)]
        tail=[x['wall']['p95_us']-y['wall']['p95_us'] for x,y in zip(v,off)]
        ratio=[x['wall']['median_us']/y['wall']['median_us'] for x,y in zip(v,off)]
        direct=[x['effect']['median_us'] for x in v];direct_tail=[x['effect']['p95_us'] for x in v]
        row=dict(repeats=v,median_added_us=statistics.median(med),median_added_p95_us=statistics.median(tail),
                 median_total_ratio=statistics.median(ratio),median_direct_effect_us=statistics.median(direct),
                 median_direct_effect_p95_us=statistics.median(direct_tail),
                 added_median_us_by_repeat=med,added_p95_us_by_repeat=tail,median_total_ratio_by_repeat=ratio)
        if mode=='off':passed=all(x==0 for x in direct+direct_tail)
        else:
            allowance, tail_allowance=(1000,2000) if mode=='full' else (250,500)
            passed=max(row['median_added_us'],row['median_direct_effect_us'])<=allowance and max(row['median_added_p95_us'],row['median_direct_effect_p95_us'])<=tail_allowance
            if mode=='full' and not group[2].endswith('transit'):passed=passed and row['median_total_ratio']<=1.35
        row['passed_effect_budget']=passed;r['passed_effect_budget'] &= passed;g['modes'][mode]=row
    r['groups'].append(g)
r['passed']=r['passed_effect_budget'] and not r['off_regression_investigations']
a.output.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k not in ('groups','notes')}))
print(json.dumps({'failed_modes':[(g['collection'],g['phase'],g['label'],g['width'],m) for g in r['groups'] for m,v in g['modes'].items() if not v['passed_effect_budget']]}))
