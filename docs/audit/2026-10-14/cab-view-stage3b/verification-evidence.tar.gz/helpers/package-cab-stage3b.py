"""Seal Stage3B raw evidence with content deduplication and full readback."""
import hashlib
import io
import json
import tarfile
from pathlib import Path

root = Path(__file__).parent / 'openspacettd-cabview'
audit = root / 'docs/audit/2026-10-14/cab-view-stage3b'
archive = audit / 'verification-evidence.tar.gz'
assert audit.is_dir() and not archive.exists()
files = {}
for folder, label in (('cab-stage3b-baseline', 'baseline'), ('cab-stage3b-candidate', 'candidate')):
    base = root / 'build' / folder
    for path in sorted(base.rglob('*')):
        if not path.is_file() or path.is_symlink():
            continue
        if path.name in ('openttd', 'openttd_test') or path.name.endswith('-openttd_test'):
            continue  # executable identities are recorded; preserved local copies remain available
        files[f'{label}/{path.relative_to(base)}'] = path
for path in sorted((root / 'build/agent-logs').glob('stage3b-*')):
    if path.is_file():
        files[f'logs/{path.name}'] = path
for pattern in ('*cab-stage3b*.py', '*cab-stage2*.py', 'prepare-cab-gate-native-fixture.py'):
    for path in sorted(root.parent.glob(pattern)):
        files[f'helpers/{path.name}'] = path
for name in ('cab-view-stage3b-start.json',):
    files[f'checkpoint/{name}'] = root.parent / name
files['fixture/cab-gate-depot-fixture.sav'] = root / 'build/cab-gate-native/fixture-01/cab-gate-depot-fixture.sav'
for name in ('test_cab_view_gate_native.py', 'test_cab_view_native.py'):
    files[f'helpers/{name}'] = root / 'scripts' / name
manifest, seen = {}, {}
with tarfile.open(archive, 'w:gz') as out:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        manifest[name] = dict(bytes=len(data), sha256=digest)
        info = tarfile.TarInfo(name)
        info.mode = 0o644
        info.mtime = 0
        if digest in seen:
            info.type = tarfile.LNKTYPE
            info.linkname = seen[digest]
            out.addfile(info)
        else:
            info.size = len(data)
            out.addfile(info, io.BytesIO(data))
            seen[digest] = name
with tarfile.open(archive) as proof:
    assert set(proof.getnames()) == set(manifest)
    for member in proof:
        data = proof.extractfile(member).read()
        assert len(data) == manifest[member.name]['bytes']
        assert hashlib.sha256(data).hexdigest() == manifest[member.name]['sha256']
record = dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
              archive_bytes=archive.stat().st_size, members=manifest,
              deduplication=dict(logical_members=len(files), unique_contents=len(seen),
                                 identical_content_hardlinks=len(files)-len(seen)))
(audit / 'archive-manifest.json').write_text(json.dumps(record, indent=2)+'\n')
verified = dict(passed=True, archive_sha256=record['archive_sha256'],
                verified_members=len(files), every_member_read_back=True,
                archive_bytes=record['archive_bytes'], deduplication=record['deduplication'])
(audit / 'archive-verification.json').write_text(json.dumps(verified, indent=2)+'\n')
print(json.dumps(verified))
