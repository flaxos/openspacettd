"""Verify matched native Stage3B evidence and summarize its bounded claims."""
import argparse
import hashlib
import json
import statistics
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--baseline-root', type=Path, required=True)
p.add_argument('--candidate-root', type=Path, required=True)
p.add_argument('--budget', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
assert not a.output.exists()
budget = json.loads(a.budget.read_text())
assert budget['passed']
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
r = dict(passed=True, runs=[], profile_cells=0, measured_frames=0, vehicle_cells=0,
         fixed_image_comparisons=0, actual_sequence_counts=[],
         max_sampled_rss_kib=0, max_vehicle_texture_payload_bytes=0,
         max_vehicle_union_pixels=0, max_cache_payload_bytes=0,
         positive_control_pixels=[], vehicle_off_warm_medians_us=[],
         max_vehicle_cold_us=0, measured_test_binary_sha256=None,
         content_matches_baseline=True, modes={}, budget_sha256=sha(a.budget))
for i in (1, 2, 3):
    bp = a.baseline_root / f'repeat-{i:02d}/gate-runner-evidence.json'
    cp = a.candidate_root / f'repeat-{i:02d}/gate-runner-evidence.json'
    base, cand = (json.loads(x.read_text()) for x in (bp, cp))
    assert base['passed'] and cand['passed'] and cand['source_save_unchanged']
    assert base['source_save_sha256'] == cand['source_save_sha256']
    run = dict(repeat=i, report_sha256=sha(cp), explicit_calls=cand['explicit_state_game_loop_calls'],
               native_pngs=0, fixed_comparisons=0, normal_changed_pixels=[], profile_cells=0)
    for before, phase in zip(base['phases'], cand['phases'], strict=True):
        assert phase['passed'] and before['phase'] == phase['phase']
        for field in ('content_sha256', 'newgrf_sha256'):
            assert before[field] == phase[field], (i, field)
        m = phase['native_manifest']
        for field in ('active_grfs', 'base_graphics', 'active_blitter', 'active_blitter_depth'):
            assert before['native_manifest'][field] == m[field], (i, field)
        r['measured_test_binary_sha256'] = r['measured_test_binary_sha256'] or phase['binary_sha256']
        assert r['measured_test_binary_sha256'] == phase['binary_sha256']
        r['max_sampled_rss_kib'] = max(r['max_sampled_rss_kib'], phase['sampled_process_memory_kib']['rss'])
        run['native_pngs'] += len(phase['screenshots'])
        run['normal_changed_pixels'].append(phase['normal_viewport_comparison']['changed_pixels'])
        assert run['normal_changed_pixels'][-1] == 0
        fixed = phase['fixed_image_comparisons']
        assert fixed['passed'] and all(c['changed_pixels'] == 0 for c in fixed['comparisons'])
        run['fixed_comparisons'] += len(fixed['comparisons'])
        for collection in ('profiles', 'vehicle_profiles'):
            for c in m[collection]:
                r['profile_cells'] += 1
                run['profile_cells'] += 1
                r['measured_frames'] += len(c['samples'])
                assert c['frozen_state_unchanged'] and c['palette_state_restored']
                if c['cache'] is not None:
                    cache = c['cache']
                    assert 0 <= cache['vehicle_textures'] <= cache['ground_textures']
                    assert 0 <= cache['vehicle_texture_payload_bytes'] <= cache['texture_payload_bytes']
                    assert 0 <= cache['max_vehicle_union_width'] <= 512
                    assert 0 <= cache['max_vehicle_union_height'] <= 512
                    assert 0 <= cache['max_vehicle_union_pixels'] <= 65536
                    r['max_vehicle_texture_payload_bytes'] = max(r['max_vehicle_texture_payload_bytes'], cache['vehicle_texture_payload_bytes'])
                    r['max_vehicle_union_pixels'] = max(r['max_vehicle_union_pixels'], cache['max_vehicle_union_pixels'])
                    r['max_cache_payload_bytes'] = max(r['max_cache_payload_bytes'], cache['cache_capacity_payload_bytes'])
                if collection == 'vehicle_profiles':
                    r['vehicle_cells'] += 1
                    assert c['cache']['vehicle_textures'] > 0
                    r['actual_sequence_counts'] += [v['raw_sequence_count'] for v in c['vehicle_sequence']]
                    r['positive_control_pixels'].append(c['visible_pixel_control']['different_pixels'])
                    r['max_vehicle_cold_us'] = max(r['max_vehicle_cold_us'], c['cold_sample']['external_total_us'])
                    if c['mode'] == 'off':
                        r['vehicle_off_warm_medians_us'].append(statistics.median(s['external_total_us'] for s in c['samples']))
    r['fixed_image_comparisons'] += run['fixed_comparisons']
    r['runs'].append(run)
r['actual_sequence_counts'] = sorted(set(r['actual_sequence_counts']))
for field in ('positive_control_pixels', 'vehicle_off_warm_medians_us'):
    values = r.pop(field)
    r[field + '_range'] = [min(values), max(values)]
for mode in ('off', 'reduced', 'full'):
    rows = [g['modes'][mode] for g in budget['groups']]
    r['modes'][mode] = {field: max(v[field] for v in rows) for field in
                        ('median_added_us', 'median_added_p95_us', 'median_direct_effect_us', 'median_direct_effect_p95_us')}
    r['modes'][mode]['max_scene_total_ratio'] = max(g['modes'][mode]['median_total_ratio'] for g in budget['groups'] if not g['label'].endswith('transit'))
r['max_off_delta_median_us'] = max(g['off_baseline_delta_median_us'] for g in budget['groups'])
r['scope'] = 'One Linux SDL-offscreen fixture; private static-palette fixed-scale measurements; human, real SpriteStack NewGRF and animated-palette UAT Pending.'
a.output.write_text(json.dumps(r, indent=2) + '\n')
print(json.dumps(r))
