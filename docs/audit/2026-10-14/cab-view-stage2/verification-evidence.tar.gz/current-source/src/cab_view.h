/* This file is part of OpenSpaceTTD. Distributed under GNU GPL version 2. */
/** @file cab_view.h Local, read-only train cab presentation state. */
#ifndef CAB_VIEW_H
#define CAB_VIEW_H

#include "vehicle_type.h"
#include "company_type.h"
#include "tile_type.h"
#include "direction_type.h"
#include "portal/portal_type.h"

struct Vehicle;

/** An immutable snapshot of the authoritative train pose for one GUI sample. */
enum class CabViewPhase : uint8_t { Unsupported, Scene, LocalTransit };

struct CabViewPresentation {
	CabViewPhase phase = CabViewPhase::Unsupported;
	WorldID world = INVALID_WORLD;
	TileIndex tile = INVALID_TILE;
	int32_t x = 0;
	int32_t y = 0;
	int32_t z = 0;
	Direction moving = Direction::Invalid;

	bool operator==(const CabViewPresentation &) const = default;
};

/** Classify a physically linked local head and both worlds without retaining a registry pointer. */
bool CabViewLocalGateVisible(TileIndex tile, WorldID selected_world);
/** Resolve current presentation from live authoritative state, without game mutation. */
CabViewPresentation ResolveCabViewPresentation(const Vehicle *v, CompanyID owner);
/** A transition invalidates every cached scene/depth/frame and pose history. */
bool CabViewTransitionRequiresReset(const CabViewPresentation &before, const CabViewPresentation &after);
/** Some discontinuities also recenter the user's transient look control. */
bool CabViewTransitionResetsLook(const CabViewPresentation &before, const CabViewPresentation &after);

bool CanShowCabView(const Vehicle *v);
void ShowCabViewWindow(const Vehicle *v);

#endif
