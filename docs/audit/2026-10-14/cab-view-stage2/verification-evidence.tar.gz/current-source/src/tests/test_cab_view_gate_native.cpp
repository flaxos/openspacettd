/* This file is part of OpenSpaceTTD. Distributed under GNU GPL version 2. */
/** @file test_cab_view_gate_native.cpp Isolated native SDL local-gate cab proof. */
#include "../stdafx.h"
#include "../3rdparty/catch2/catch.hpp"
#include "../3rdparty/nlohmann/json.hpp"
#include "../cab_view.h"
#include "../cab_view_3d.h"
#include "../base_media_graphics.h"
#include "../company_base.h"
#include "../command_func.h"
#include "../console_func.h"
#include "../console_internal.h"
#include "../core/random_func.hpp"
#include "../core/backup_type.hpp"
#include "../direction_func.h"
#include "../gfx_func.h"
#include "../map_func.h"
#include "../misc/endian_buffer.hpp"
#include "../openttd.h"
#include "../order_base.h"
#include "../order_cmd.h"
#include "../portal/planet_manager.h"
#include "../portal/portal_registry.h"
#include "../portal/stellar_network.h"
#include "../saveload/saveload_func.h"
#include "../screenshot.h"
#include "../safeguards.h"
#include "../timer/timer_game_calendar.h"
#include "../timer/timer_game_tick.h"
#include "../train.h"
#include "../train_cmd.h"
#include "../tunnel_map.h"
#include "../tunnelbridge_map.h"
#include "../vehicle_cmd.h"
#include "../vehicle_gui.h"
#include "../video/video_driver.hpp"
#include "../viewport_func.h"
#include "../window_func.h"
#include "../window_gui.h"
#include <atomic>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <thread>

namespace {
namespace fs = std::filesystem;
using Json = nlohmann::json;
using Clock = std::chrono::steady_clock;
TileIndex GateA() { return TileXY(70, 40); }
TileIndex GateB() { return TileXY(112, 40); }
constexpr unsigned PASS_LIMIT = 8192;
constexpr unsigned TOTAL_LIMIT = 24576;

Json OrderState(const Order &o)
{
	/* Exact command serialization includes packed type/flags, preserving every
	 * non-stop, stop-location and timetable bit for cold/paused equality. */
	return {{"packed", EndianBufferWriter<>::FromValue(o)},
		{"type", static_cast<int>(o.GetType())}, {"destination", o.GetDestination().value},
		{"load", static_cast<int>(o.GetLoadType())}, {"unload", static_cast<int>(o.GetUnloadType())},
		{"non_stop", o.GetNonStopType().base()}, {"stop_location", static_cast<int>(o.GetStopLocation())},
		{"depot_type", o.GetDepotOrderType().base()}, {"depot_action", o.GetDepotActionType().base()},
		{"conditional_variable", static_cast<int>(o.GetConditionVariable())},
		{"conditional_comparator", static_cast<int>(o.GetConditionComparator())},
		{"conditional_skip", o.GetConditionSkipToOrder()}, {"conditional_value", o.GetConditionValue()},
		{"refit", static_cast<int>(o.GetRefitCargo())}, {"wait", o.GetWaitTime()},
		{"travel", o.GetTravelTime()}, {"wait_timetabled", o.IsWaitTimetabled()},
		{"travel_timetabled", o.IsTravelTimetabled()}, {"max_speed", o.GetMaxSpeed()}};
}

Json ConsistState(const Train *front)
{
	Json cars = Json::array();
	for (const Train *car = front; car != nullptr; car = car->Next()) {
		Json packets = Json::array();
		for (const CargoPacket *packet : *car->cargo.Packets()) {
			const Source source = packet->GetSource();
			packets.push_back({{"count", packet->Count()}, {"age", packet->GetPeriodsInTransit()},
				{"source_id", source.id}, {"source_type", static_cast<int>(source.type)},
				{"source_tile", packet->GetSourceXY().base()}, {"first_station", packet->GetFirstStation().base()},
				{"feeder", packet->GetFeederShare().base()}});
		}
		cars.push_back({{"id", car->index.base()}, {"engine", car->engine_type.base()},
			{"owner", car->owner.base()}, {"tile", car->tile.base()}, {"world", PlanetManager::GetTileWorld(car->tile).base()},
			{"x", car->x_pos}, {"y", car->y_pos}, {"z", car->z_pos},
			{"direction", static_cast<int>(car->direction)}, {"moving", static_cast<int>(car->GetMovingDirection())},
			{"track", car->track.base()}, {"hidden", car->vehstatus.Test(VehState::Hidden)},
			{"stopped", car->vehstatus.Test(VehState::Stopped)}, {"speed", car->cur_speed},
			{"cargo_type", static_cast<int>(car->cargo_type)}, {"cargo_capacity", car->cargo_cap},
			{"cargo_stored", car->cargo.StoredCount()}, {"cargo_reserved", car->cargo.ReservedCount()},
			{"cargo_total", car->cargo.TotalCount()}, {"cargo_feeder", car->cargo.GetFeederShare().base()},
			{"packets", std::move(packets)}});
	}
	return cars;
}

Json FrozenState(const Train *front)
{
	Json orders = Json::array();
	for (int i = 0; i < front->GetNumOrders(); ++i) orders.push_back(OrderState(*front->GetOrder(i)));
	Json worlds = Json::array();
	for (const auto &[id, world] : StellarNetwork::Worlds()) worlds.push_back({{"id", id.base()},
		{"name", world.name}, {"opened", world.opened}, {"x", world.x}, {"y", world.y}});
	Json regions = Json::array();
	for (const PlanetRegion &r : PlanetManager::GetAllRegions()) regions.push_back({{"id", r.id.base()},
		{"min_x", r.min_x}, {"max_x", r.max_x}, {"min_y", r.min_y}, {"max_y", r.max_y}});
	Json transit = Json::array();
	for (const auto &[vehicle, distance] : PortalRegistry::GetAllVehicleTransit()) transit.push_back({vehicle, distance});
	std::sort(transit.begin(), transit.end());
	const PortalLink *link = PortalRegistry::GetPortalLink(GateA());
	Json gate = nullptr;
	if (link != nullptr) gate = {{"id", link->id.base()}, {"a_tile", link->end_a.tile.base()},
		{"a_world", link->end_a.world_id.base()}, {"a_dir", static_cast<int>(link->end_a.enter_dir)},
		{"b_tile", link->end_b.tile.base()}, {"b_world", link->end_b.world_id.base()},
		{"b_dir", static_cast<int>(link->end_b.enter_dir)}, {"bidirectional", link->bidirectional},
		{"virtual_length", link->virtual_length}};
	return {{"train_id", front->index.base()}, {"owner", front->owner.base()},
		{"tick", TimerGameTick::counter}, {"date", TimerGameCalendar::date.base()},
		{"date_fract", TimerGameCalendar::date_fract}, {"rng", {_random.state[0], _random.state[1]}},
		{"money", Company::Get(front->owner)->money.base()}, {"current_order", OrderState(front->current_order)},
		{"real_order_index", front->cur_real_order_index}, {"implicit_order_index", front->cur_implicit_order_index},
		{"orders", std::move(orders)}, {"cars", ConsistState(front)}, {"gate", gate},
		{"transit", std::move(transit)}, {"worlds", std::move(worlds)}, {"regions", std::move(regions)}};
}

enum class Phase { Start, Warmup, Open, Outbound, OutboundSafe, Return, Finish,
	NormalBefore, ReopenForRecovery, NormalAfter };
struct GateNativeProof {
	fs::path output;
	fs::path expected;
	Clock::time_point started_at = Clock::now();
	Phase phase = Phase::Start;
	VehicleID id = VehicleID::Invalid();
	WorldID source = INVALID_WORLD, destination = INVALID_WORLD;
	Json manifest = {{"passed", false}, {"events", Json::array()}, {"screenshots", Json::array()}};
	Json paused_baseline;
	std::string pending_shot, failure;
	unsigned callbacks = 0, total_calls = 0, pass_calls = 0;
	unsigned pass = 0;
	bool pass_started[2]{};
	bool cold = false, started = false, finished = false;
	bool approach[2]{}, hidden[2]{}, arrived[2]{}, mixed[2]{};
	bool cab_opened = false, grew_consist = false, cold_equal = false;
	bool saw_normal_recovery = false;
	bool check_pending_purity = false;
	unsigned warmup_calls = 0;

	Train *Front() const { return Train::GetIfValid(this->id); }
	Window *Cab() const { return FindWindowById(WindowClass::VehicleCabView, this->id); }
	void Event(std::string_view label)
	{
		const Train *front = this->Front();
		this->manifest["events"].push_back({{"name", label}, {"elapsed_ms", std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now() - this->started_at).count()},
			{"explicit_calls", this->total_calls}, {"game_tick", TimerGameTick::counter},
			{"train_x", front == nullptr ? -1 : front->x_pos}, {"train_y", front == nullptr ? -1 : front->y_pos},
			{"train_tile", front == nullptr ? -1 : static_cast<int>(front->tile.base())}});
	}
	void Write() const
	{
		std::ofstream file(this->output / "gate-native-manifest.json", std::ios::trunc);
		file << this->manifest.dump(2) << '\n';
	}
	void Fail(std::string_view message)
	{
		this->failure = message;
		this->manifest["failure"] = message;
		this->Event("failed");
		CloseWindowByClass(WindowClass::VehicleCabView);
		this->Write();
		_exit_game = true;
	}
	void Schedule() { VideoDriver::GetInstance()->QueueOnMainThread([this] { this->Tick(); }); }
	bool Capture(std::string_view name)
	{
		this->pending_shot = fmt::format("gate_{}_{}", this->cold ? "cold" : "roundtrip", name);
		this->Event(fmt::format("capture_{}", name));
		if (!MakeScreenshot(SC_VIEWPORT, this->pending_shot)) { this->Fail("native screenshot could not be queued"); return false; }
		this->Schedule();
		return true;
	}
	bool Collect()
	{
		if (this->pending_shot.empty()) return true;
		const fs::path source_path(_full_screenshot_path);
		if (!fs::is_regular_file(source_path) || !source_path.filename().string().starts_with(this->pending_shot + ".")) {
			this->Fail("native screenshot missing"); return false;
		}
		const fs::path target = this->output / (this->pending_shot + source_path.extension().string());
		std::error_code error;
		fs::copy_file(source_path, target, fs::copy_options::overwrite_existing, error);
		if (error || fs::file_size(target) == 0) { this->Fail("native screenshot copy failed"); return false; }
		this->manifest["screenshots"].push_back(target.filename().string());
		this->pending_shot.clear();
		return true;
	}
	bool PauseAndCapture(std::string_view name)
	{
		if (!_pause_mode.Test(PauseMode::Normal)) IConsoleCmdExec("pause");
		if (!_pause_mode.Test(PauseMode::Normal)) { this->Fail("could not pause observed native phase"); return false; }
		this->paused_baseline = FrozenState(this->Front());
		if (this->Cab() != nullptr) this->Cab()->OnRealtimeTick(0);
		if (!this->Pure()) return false;
		this->check_pending_purity = true;
		return this->Capture(name);
	}
	bool Unpause()
	{
		if (_pause_mode.Test(PauseMode::Normal)) IConsoleCmdExec("unpause");
		if (_pause_mode.Any()) { this->Fail("native game stayed paused"); return false; }
		return true;
	}
	bool Advance()
	{
		if (this->pass_calls >= PASS_LIMIT || this->total_calls >= TOTAL_LIMIT) { this->Fail("explicit StateGameLoop budget exhausted"); return false; }
		++this->pass_calls;
		++this->total_calls;
		StateGameLoop();
		return true;
	}
	bool Pure()
	{
		if (!_pause_mode.Test(PauseMode::Normal) || this->Front() == nullptr || FrozenState(this->Front()) != this->paused_baseline) {
			this->Fail("paused camera changed train/orders/cargo, gate/world, RNG/date/tick or cash"); return false;
		}
		return true;
	}
	bool ProbeRenderedMixed(WorldID target)
	{
		/* A private, real-base CPU render at the frozen native game state.
		 * Excluding an already-masked car must leave every pixel unchanged;
		 * excluding an arrived visible car must change pixels. This exercises
		 * AddVehicles through the actual rasterizer, beyond the policy helper. */
		if (!_pause_mode.Test(PauseMode::Normal)) IConsoleCmdExec("pause");
		if (!_pause_mode.Test(PauseMode::Normal)) { this->Fail("mixed render could not pause"); return false; }
		Train *visible = nullptr;
		for (Train *car = this->Front(); car != nullptr; car = car->Next()) {
			if (CabViewVehicleVisible(car, target)) { visible = car; break; }
		}
		if (visible == nullptr) { this->Fail("mixed render has no arrived positive control"); return false; }
		const Json frozen = FrozenState(this->Front());
		CabViewCamera camera;
		camera.x = visible->x_pos;
		camera.y = visible->y_pos + 2.5f * TILE_SIZE;
		camera.z = visible->z_pos + 7;
		camera.yaw = -static_cast<float>(M_PI) / 2;
		camera.world = target;
		constexpr int width = 160, height = 100;
		auto paint = [&](VehicleID omitted) {
			std::vector<Colour> pixels(width * height);
			DrawPixelInfo dpi{pixels.data(), 0, 0, width, height, width, ZoomLevel::Min};
			camera.vehicle = omitted;
			{
				/* 32bpp MoveTo uses _screen.pitch, while 32bpp-anim otherwise
				 * addresses the live animation buffer. Match the engine's own
				 * offscreen convention and restore all three globals. */
				AutoRestoreBackup screen_backup(_screen, dpi);
				AutoRestoreBackup dpi_backup(_cur_dpi, &dpi);
				AutoRestoreBackup anim_backup(_screen_disable_anim, true);
				ResetCabView3D();
				DrawCabView3D({0, 0, width - 1, height - 1}, camera, 1, 0);
			}
			return pixels;
		};
		const auto baseline = paint(VehicleID::Invalid());
		unsigned masked = 0;
		for (const Train *car = this->Front(); car != nullptr; car = car->Next()) {
			if (CabViewVehicleVisible(car, target)) continue;
			if (paint(car->index) != baseline) { this->Fail("masked car changed actual CPU render pixels"); return false; }
			++masked;
		}
		if (masked < 2 || paint(visible->index) == baseline) {
			this->Fail("mixed CPU render lacked masked cars or visible-car positive control"); return false;
		}
		ResetCabView3D();
		if (FrozenState(this->Front()) != frozen) { this->Fail("diagnostic CPU render changed frozen game state"); return false; }
		this->manifest["mixed_render_proof"].push_back({{"pass", this->pass}, {"masked_car_count", masked},
			{"visible_positive_control", visible->index.base()}, {"width", width}, {"height", height}});
		return true;
	}
	bool CheckColdAtStartup()
	{
		/* The startup script runs as the load completes, before a queued draw
		 * callback or an explicit StateGameLoop call can advance the game. */
		if (FindWindowByClass(WindowClass::VehicleCabView) != nullptr) { this->Fail("cab unexpectedly persisted after cold load"); return false; }
		Train *front = Train::GetIfValid(VehicleID{0});
		if (front == nullptr || front->owner != _local_company) { this->Fail("cold primary train missing"); return false; }
		std::ifstream file(this->expected);
		if (!file) { this->Fail("cold expected snapshot missing"); return false; }
		Json expected = Json::parse(file);
		Json now = FrozenState(front);
		if (now != expected) {
			std::ofstream(this->output / "cold-actual-snapshot.json") << now.dump(2) << '\n';
			this->Fail("cold load differs from frozen full orders/consist/cargo/world/gate/RNG/date/cash snapshot"); return false;
		}
		this->cold_equal = true;
		this->Event("cold_snapshot_equal_before_advance");
		if (!_pause_mode.Test(PauseMode::Normal)) IConsoleCmdExec("pause");
		return true;
	}
	bool SetupFourCars()
	{
		Train *front = Train::GetIfValid(VehicleID{0});
		if (front == nullptr || !front->IsInDepot() || front->owner != _local_company) { this->Fail("fixture train 0 is not owned in depot"); return false; }
		this->id = front->index;
		Train *wagon = front->Next();
		if (wagon == nullptr || wagon->Next() != nullptr) { this->Fail("fixture train needs exactly one initial wagon"); return false; }
		if (!front->vehstatus.Test(VehState::Stopped) &&
			Command<Commands::StartStopVehicle>::Do(DoCommandFlag::Execute, front->index, false).Failed()) {
			this->Fail("fixture stop command failed"); return false;
		}
		for (unsigned i = 0; i < 2; ++i) {
			auto [cost, new_id, capacity, mail, cargo] = Command<Commands::BuildVehicle>::Do(
				DoCommandFlag::Execute, front->tile, wagon->engine_type, false, wagon->cargo_type, ClientID::Invalid);
			if (cost.Failed()) { this->Fail("fixture wagon build command failed"); return false; }
			if (Train::Get(new_id)->First()->index != front->index &&
				Command<Commands::MoveRailVehicle>::Do(DoCommandFlag::Execute, new_id, front->Last()->index, false).Failed()) {
				this->Fail("fixture wagon build/couple command failed"); return false;
			}
			this->Event("fixture_build_and_couple_wagon");
		}
		unsigned count = 0;
		for (const Train *car = front; car != nullptr; car = car->Next()) ++count;
		if (count != 4) { this->Fail("fixture did not create four-car consist"); return false; }
		this->grew_consist = true;
		if (Command<Commands::StartStopVehicle>::Do(DoCommandFlag::Execute, front->index, false).Failed()) {
			this->Fail("fixture restart command failed"); return false;
		}
		this->Event("fixture_start_train");
		return true;
	}
	bool StartPass(unsigned index)
	{
		Train *front = this->Front();
		if (front == nullptr || front->GetNumOrders() < 2) { this->Fail("fixture train/order missing"); return false; }
		if (!this->Unpause()) return false;
		if (index == 1) {
			if (Command<Commands::ReverseTrainDirection>::Do(DoCommandFlag::Execute, front->index, false).Failed()) {
				this->Fail("native reverse command failed"); return false;
			}
			this->Event("fixture_reverse_train_command");
		}
		if (Command<Commands::SkipToOrder>::Do(DoCommandFlag::Execute, front->index,
			static_cast<VehicleOrderID>(index == 0 ? 1 : 0)).Failed()) {
			this->Fail("native skip-to-order command failed"); return false;
		}
		this->Event("fixture_skip_to_order_command");
		this->pass = index;
		/* The initial depot warmup is charged to the first directional pass. */
		if (index != 0) this->pass_calls = 0;
		this->pass_started[index] = true;
		return true;
	}
	void Observe()
	{
		Train *front = this->Front();
		if (front == nullptr || this->Cab() == nullptr) { this->Fail("native primary train/cab vanished"); return; }
		const CabViewPresentation state = ResolveCabViewPresentation(front, front->owner);
		const WorldID origin = this->pass == 0 ? this->source : this->destination;
		const WorldID target = this->pass == 0 ? this->destination : this->source;
		const TileIndex gate = this->pass == 0 ? GateA() : GateB();
		if (!this->approach[this->pass] && state.phase == CabViewPhase::Scene && state.world == origin &&
			state.moving == DiagDirToDir(GetTunnelBridgeDirection(gate)) &&
			std::abs(front->x_pos - static_cast<int>(TileX(gate) * TILE_SIZE)) < 10 * static_cast<int>(TILE_SIZE)) {
			this->approach[this->pass] = true; this->Event("observed_approach");
			this->PauseAndCapture(this->pass == 0 ? "out_approach" : "back_approach"); return;
		}
		if (!this->hidden[this->pass] && state.phase == CabViewPhase::LocalTransit) {
			this->hidden[this->pass] = true; this->Event("observed_opaque_transit");
			this->PauseAndCapture(this->pass == 0 ? "out_transit" : "back_transit"); return;
		}
		const bool new_arrival = !this->arrived[this->pass] && state.phase == CabViewPhase::Scene && state.world == target;
		if (new_arrival) { this->arrived[this->pass] = true; this->Event("observed_arrival"); }
		bool new_mixed = false;
		if (this->arrived[this->pass] && !this->mixed[this->pass]) {
			unsigned target_units = 0, hidden_units = 0, origin_units = 0;
			Json mask = Json::array();
			for (Train *car = front; car != nullptr; car = car->Next()) {
				const WorldID car_world = PlanetManager::GetTileWorld(car->tile);
				const bool hidden = car->vehstatus.Test(VehState::Hidden) || car->track == Track::Wormhole;
				if (hidden) ++hidden_units;
				else if (car_world == target) ++target_units;
				else if (car_world == origin) ++origin_units;
				const bool visible = CabViewVehicleVisible(car, target);
				if (visible != (!hidden && car_world == target)) { this->Fail("per-car native world mask differs from expected state"); return; }
				mask.push_back({{"id", car->index.base()}, {"world", car_world.base()}, {"hidden", hidden}, {"visible", visible}});
			}
			if (target_units > 0 && hidden_units > 0 && origin_units > 0) {
				this->mixed[this->pass] = true; this->manifest["mixed_world_mask"].push_back(mask);
				this->Event("observed_three_state_consist");
				new_mixed = true;
			}
		}
		/* Arrival and all three car states can coexist for only one native
		 * tick. Inspect both before pausing for their shared rendered frame. */
		if (new_arrival || new_mixed) {
			if (new_mixed && !this->ProbeRenderedMixed(target)) return;
			const std::string_view name = this->pass == 0 ?
				(new_arrival && new_mixed ? "out_arrival_mixed" : new_arrival ? "out_arrival" : "out_mixed") :
				(new_arrival && new_mixed ? "back_arrival_mixed" : new_arrival ? "back_arrival" : "back_mixed");
			this->PauseAndCapture(name);
			return;
		}
		if (!this->approach[this->pass] || !this->hidden[this->pass] || !this->arrived[this->pass] || !this->mixed[this->pass]) return;
		bool all_target = true;
		for (const Train *car = front; car != nullptr; car = car->Next()) {
			if (car->vehstatus.Test(VehState::Hidden) || PlanetManager::GetTileWorld(car->tile) != target) all_target = false;
		}
		if (!all_target || state.phase != CabViewPhase::Scene ||
			std::abs(front->x_pos - static_cast<int>((TileX(this->pass == 0 ? GateB() : GateA())) * TILE_SIZE)) < 5 * static_cast<int>(TILE_SIZE)) return;
		this->Event("observed_safe_endpoint");
		if (!this->PauseAndCapture(this->pass == 0 ? "out_safe" : "back_safe")) return;
		this->phase = this->pass == 0 ? Phase::OutboundSafe : Phase::Finish;
	}
	void Tick()
	{
		if (this->finished || !this->failure.empty()) return;
		if (++this->callbacks > 3000 || Clock::now() - this->started_at > std::chrono::seconds(180)) {
			this->Fail("native callback or 180-second controller budget exhausted"); return;
		}
		if (!this->Collect()) return;
		if (this->check_pending_purity) {
			if (!this->Pure()) return;
			this->check_pending_purity = false;
		}
		if (this->phase == Phase::Start) {
			if (_game_mode != GameMode::Normal || _switch_mode != SwitchMode::None) { this->Schedule(); return; }
			Train *front = Train::GetIfValid(VehicleID{0});
			if (front == nullptr || front->owner != _local_company) { this->Fail("owned train 0 missing"); return; }
			this->id = front->index;
			this->source = PlanetManager::GetTileWorld(GateA());
			this->destination = PlanetManager::GetTileWorld(GateB());
			if (this->source == INVALID_WORLD || this->destination == INVALID_WORLD || this->source == this->destination) {
				this->Fail("local gate worlds missing"); return;
			}
			if (this->cold) {
				if (!this->cold_equal) { this->Fail("cold startup comparison did not execute before first callback"); return; }
				this->phase = Phase::Open;
			} else {
				if (!this->SetupFourCars()) return;
				this->phase = Phase::Warmup;
			}
			this->Schedule(); return;
		}
		if (this->phase == Phase::Warmup) {
			Train *front = this->Front();
			if (front == nullptr) { this->Fail("warmup lost train"); return; }
			if (CanShowCabView(front) && front->x_pos >= 18 * static_cast<int>(TILE_SIZE)) {
				IConsoleCmdExec("pause");
				this->phase = Phase::Open; this->Event("warmup_visible_ground"); this->Schedule(); return;
			}
			if (!this->Unpause() || !this->Advance()) return;
			++this->warmup_calls;
			if (this->pending_shot.empty()) this->Schedule();
			return;
		}
		if (this->phase == Phase::Open) {
			if (!_pause_mode.Test(PauseMode::Normal)) IConsoleCmdExec("pause");
			if (!CanShowCabView(this->Front())) { this->Fail("safe native cab open was rejected"); return; }
			this->paused_baseline = FrozenState(this->Front());
			ShowCabViewWindow(this->Front());
			if (this->Cab() == nullptr || !this->Pure()) { if (this->failure.empty()) this->Fail("native cab did not open"); return; }
			this->cab_opened = true;
			this->phase = this->cold ? Phase::Return : Phase::Outbound;
			this->check_pending_purity = true;
			this->Capture(this->cold ? "cold_reopened" : "initial_cab"); return;
		}
		if (this->phase == Phase::OutboundSafe) {
			if (!this->Pure()) return;
			const fs::path save = this->output / "gate-checkpoint.sav";
			if (SaveOrLoad(save.string(), SaveLoadOperation::Save, DetailedFileType::GameFile, Subdirectory::None, false) != SaveLoadResult::Ok) {
				this->Fail("native checkpoint save failed"); return;
			}
			std::ofstream(this->output / "gate-checkpoint.json") << FrozenState(this->Front()).dump(2) << '\n';
			this->Event("native_checkpoint_saved");
			this->phase = Phase::Return;
			this->Schedule(); return;
		}
		if (this->phase == Phase::Finish) {
			if (!this->Pure()) return;
			CloseWindowByClass(WindowClass::VehicleCabView);
			if (this->Cab() != nullptr) { this->Fail("cab failed to close after gate return"); return; }
			ScrollMainWindowToTile(this->Front()->tile, true);
			this->phase = Phase::NormalBefore;
			this->Capture("normal_before_reopen");
			return;
		}
		if (this->phase == Phase::NormalBefore) {
			if (!this->Pure()) return;
			ShowCabViewWindow(this->Front());
			if (this->Cab() == nullptr) { this->Fail("cab failed recovery reopen"); return; }
			this->phase = Phase::ReopenForRecovery;
			this->Capture("reopened_for_recovery");
			return;
		}
		if (this->phase == Phase::ReopenForRecovery) {
			if (!this->Pure()) return;
			CloseWindowByClass(WindowClass::VehicleCabView);
			if (this->Cab() != nullptr) { this->Fail("cab failed recovery reclose"); return; }
			this->phase = Phase::NormalAfter;
			this->Capture("normal_after_reopen_close");
			return;
		}
		if (this->phase == Phase::NormalAfter) {
			if (!this->Pure()) return;
			this->saw_normal_recovery = true;
			this->finished = true;
			this->manifest["passed"] = true;
			this->manifest["explicit_state_game_loop_calls"] = this->total_calls;
			this->manifest["automatic_game_tick_counter"] = TimerGameTick::counter;
			this->manifest["base_graphics"] = BaseGraphics::GetUsedSet() == nullptr ? "" : BaseGraphics::GetUsedSet()->name;
			this->Write();
			_exit_game = true;
			return;
		}
		if (this->phase == Phase::Outbound || this->phase == Phase::Return) {
			const unsigned index = this->phase == Phase::Outbound ? 0 : 1;
			if (!this->pass_started[index] && !this->StartPass(index)) return;
			if (_pause_mode.Test(PauseMode::Normal) && !this->Unpause()) return;
			/* Every explicit game tick is inspected. The native transit can last
			 * fewer ticks than a draw callback, so never batch unobserved ticks. */
			for (unsigned i = 0; i < 16 && this->pending_shot.empty() && this->phase != Phase::Finish && this->phase != Phase::OutboundSafe; ++i) {
				if (!this->Advance()) return;
				this->Observe();
				if (!this->failure.empty()) return;
			}
			if (this->pending_shot.empty()) this->Schedule();
			return;
		}
	}
};

GateNativeProof *active_gate_proof = nullptr;
bool StartGateProof(std::span<std::string_view> args)
{
	if (args.size() != 1 || active_gate_proof == nullptr || active_gate_proof->started) return false;
	active_gate_proof->started = true;
	if (active_gate_proof->cold && !active_gate_proof->CheckColdAtStartup()) return false;
	active_gate_proof->Schedule();
	return true;
}
} // namespace

TEST_CASE("Native SDL local gate cab round trip and cold reload", "[.][cab-view][gate-native]")
{
	const char *config = std::getenv("OSTTD_CAB_NATIVE_CONFIG");
	const char *save = std::getenv("OSTTD_CAB_NATIVE_SAVE");
	const char *output = std::getenv("OSTTD_CAB_NATIVE_OUTPUT");
	const char *binary = std::getenv("OSTTD_CAB_NATIVE_BINARY");
	const char *phase = std::getenv("OSTTD_CAB_GATE_PHASE");
	REQUIRE(config != nullptr); REQUIRE(save != nullptr); REQUIRE(output != nullptr); REQUIRE(binary != nullptr); REQUIRE(phase != nullptr);
	REQUIRE(fs::is_regular_file(config)); REQUIRE(fs::is_regular_file(save)); REQUIRE(fs::is_regular_file(binary));
	GateNativeProof proof;
	proof.output = fs::canonical(output);
	proof.cold = std::string_view(phase) == "cold";
	REQUIRE((proof.cold || std::string_view(phase) == "roundtrip"));
	if (proof.cold) {
		const char *expected = std::getenv("OSTTD_CAB_GATE_EXPECTED");
		REQUIRE(expected != nullptr);
		proof.expected = expected;
	}
	proof.manifest["phase"] = phase;
	proof.manifest["mixed_world_mask"] = Json::array();
	proof.manifest["mixed_render_proof"] = Json::array();
	active_gate_proof = &proof;
	IConsole::CmdRegister("cab_gate_native_start", StartGateProof);
	std::array<std::string, 14> arguments = {binary, "-v", "sdl", "-b", "32bpp-anim", "-s", "null", "-m", "null", "-r", "1280x800", "-x", "-c", config};
	std::vector<std::string_view> views;
	for (const std::string &argument : arguments) views.push_back(argument);
	views.push_back("-g"); views.push_back(save);
	std::mutex mutex;
	std::condition_variable condition;
	bool stopped = false;
	std::atomic<bool> timed_out{false};
	std::thread watchdog([&] {
		std::unique_lock lock(mutex);
		if (!condition.wait_for(lock, std::chrono::seconds(185), [&] { return stopped; })) {
			timed_out = true;
			_exit_game = true;
		}
	});
	const int exit_code = openttd_main(views);
	{
		std::lock_guard lock(mutex);
		stopped = true;
	}
	condition.notify_one(); watchdog.join();
	active_gate_proof = nullptr;
	if (!proof.finished || !proof.failure.empty()) proof.Write();
	INFO("Stage 2 native manifest: " << (proof.output / "gate-native-manifest.json"));
	INFO("Stage 2 native failure: " << proof.failure);
	CHECK_FALSE(timed_out); CHECK(exit_code == 0); CHECK(proof.started); CHECK(proof.finished);
	CHECK(proof.failure.empty()); CHECK(proof.cab_opened);
	CHECK(proof.approach[1]); CHECK(proof.hidden[1]); CHECK(proof.arrived[1]); CHECK(proof.mixed[1]);
	if (!proof.cold) {
		CHECK(proof.grew_consist); CHECK(proof.approach[0]); CHECK(proof.hidden[0]);
		CHECK(proof.arrived[0]); CHECK(proof.mixed[0]);
	} else {
		CHECK(proof.cold_equal);
	}
	CHECK(proof.saw_normal_recovery);
}
