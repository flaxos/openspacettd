/* This file is part of OpenSpaceTTD. Distributed under GNU GPL version 2. */
/** @file test_cab_view.cpp Regression checks for the Stage 1 train cab view. */
#include "../stdafx.h"
#include "../3rdparty/catch2/catch.hpp"
#include "mock_environment.h"
#include "../cab_view_3d.h"
#include "../cab_view.h"
#include "../viewport_func.h"
#include "../map_func.h"
#include "../clear_map.h"
#include "../void_map.h"
#include "../direction_func.h"
#include "../tunnel_map.h"
#include "../portal/portal_registry.h"
#include "../portal/planet_manager.h"
#include "../portal/stellar_network.h"
#include "../blitter/factory.hpp"
#include "../gfx_func.h"
#include "../gfxinit.h"
#include "../base_media_graphics.h"
#include "../engine_base.h"
#include "../engine_func.h"
#include "../cargotype.h"
#include "../town.h"
#include "../newgrf_house.h"
#include "../road.h"
#include "../settings_type.h"
#include "../table/sprites.h"
#include "../core/random_func.hpp"
#include "../core/backup_type.hpp"
#include "../timer/timer_game_calendar.h"
#include "../vehicle_base.h"
#include "../train.h"
#include "../company_func.h"
#include "../openttd.h"
#include "../video/null_v.h"
#include "../driver.h"
#include "../fileio_func.h"
#include "../language.h"
#include "../strings_func.h"
#include "../safeguards.h"
#include "../window_func.h"
#include "../window_gui.h"
#include <filesystem>

extern EnumIndexArray<std::string, Searchpath, Searchpath::End> _searchpaths;

static void SetupCabMap()
{
	(void)MockEnvironment::Instance();
	_vehicle_pool.CleanPool();
	PortalRegistry::Reset();
	Map::Allocate(64, 64);
	for (TileIndex tile{0}; tile < Map::Size(); ++tile) {
		if (IsInnerTile(tile) && TileX(tile) != 0 && TileY(tile) != 0) MakeClear(tile, ClearGround::Grass, 0);
		else MakeVoid(tile);
	}
	StellarNetwork::Reset();
	PlanetManager::Reset();
}

/** Physical heads and world regions, not a registry-only fictitious pair. */
static std::pair<TileIndex, TileIndex> SetupCabLocalGate()
{
	SetupCabMap();
	PlanetRegion a;
	a.id = WorldID{0};
	a.min_x = a.min_y = 1;
	a.max_x = 20;
	a.max_y = 40;
	PlanetRegion b;
	b.id = WorldID{1};
	b.min_x = 22;
	b.max_x = 42;
	b.min_y = 1;
	b.max_y = 40;
	REQUIRE(PlanetManager::RegisterRegion(a));
	REQUIRE(PlanetManager::RegisterRegion(b));
	StellarNetwork::RegisterWorld({WorldID{0}, "home", "Home", 0, 0, true});
	StellarNetwork::RegisterWorld({WorldID{1}, "other", "Other", 10, 0, true});
	const TileIndex entry = TileXY(10, 10);
	const TileIndex exit = TileXY(30, 10);
	MakeRailTunnel(entry, Owner{0}, DiagDirection::SW, RAILTYPE_BEGIN);
	MakeRailTunnel(exit, Owner{0}, DiagDirection::NE, RAILTYPE_BEGIN);
	REQUIRE(PortalRegistry::RegisterPortalPair(entry, DiagDirection::SW, WorldID{0},
		exit, DiagDirection::NE, WorldID{1}) != INVALID_PORTAL);
	return {entry, exit};
}

class CabTestVideoDriver final : public VideoDriver_Null {
public:
	std::optional<std::string_view> Start(const StringList &) override { return std::nullopt; }
	bool HasGUI() const override { return true; }
};

class CabTestVideoDriverFactory final : public DriverFactoryBase {
public:
	CabTestVideoDriverFactory() : DriverFactoryBase(Driver::Type::Video, 0, "cabtest", "Cab test video driver") {}
	std::unique_ptr<Driver> CreateInstance() const override { return std::make_unique<CabTestVideoDriver>(); }
};

TEST_CASE("Cab entry rejects foreign nonprimary and unsupported train states", "[.][cab-view][gui]")
{
	SetupCabMap();
	CabTestVideoDriverFactory video_factory;
	DriverFactoryBase::SelectDriver("cabtest", Driver::Type::Video);
	Blitter *blitter = BlitterFactory::SelectBlitter("32bpp-simple");
	DrawPixelInfo old_screen = _screen;
	GameMode old_mode = _game_mode;
	SwitchMode old_switch = _switch_mode;
	CompanyID old_company = _local_company;
	_screen.width = _screen.height = 100;
	_game_mode = GameMode::Normal;
	_switch_mode = SwitchMode::None;
	_local_company = CompanyID{0};
	REQUIRE(Vehicle::CanAllocateItem());
	Train *train = Vehicle::Create<Train>();
	train->SetFrontEngine();
	train->owner = CompanyID{0};
	train->tile = TileXY(8, 8);
	train->x_pos = train->y_pos = 8 * TILE_SIZE + 8;
	train->direction = Direction::SW;
	train->track = Track::X;
	train->vehstatus.Reset(VehState::Hidden);
	if (blitter != nullptr) {
		CHECK(CanShowCabView(train));
		train->owner = CompanyID{1};
		CHECK_FALSE(CanShowCabView(train));
		train->owner = CompanyID{0};
		train->ClearFrontEngine();
		CHECK_FALSE(CanShowCabView(train));
		train->SetFrontEngine();
		train->tile = TileXY(0, 0);
		CHECK_FALSE(CanShowCabView(train));
		train->tile = TileXY(8, 8);
		_game_mode = GameMode::Menu;
		CHECK_FALSE(CanShowCabView(train));
		_game_mode = GameMode::Normal;
	}
	CHECK(blitter != nullptr);
	_vehicle_pool.CleanPool();
	_local_company = old_company;
	_game_mode = old_mode;
	_switch_mode = old_switch;
	_screen = old_screen;
	BlitterFactory::SelectBlitter("null");
	DriverFactoryBase::SelectDriver("null", Driver::Type::Video);
}

TEST_CASE("Cab window is singleton and closes on session change or train deletion", "[.][cab-view][gui]")
{
	SetupCabMap();
	_searchpaths[Searchpath::BinaryDir] = std::filesystem::exists("build/lang/english.lng") ? "build/" : "./";
	_valid_searchpaths = {Searchpath::BinaryDir};
	InitializeLanguagePacks();
	CabTestVideoDriverFactory video_factory;
	DriverFactoryBase::SelectDriver("cabtest", Driver::Type::Video);
	Blitter *blitter = BlitterFactory::SelectBlitter("32bpp-simple");
	REQUIRE(blitter != nullptr);
	const DrawPixelInfo old_screen = _screen;
	const GameMode old_mode = _game_mode;
	const SwitchMode old_switch = _switch_mode;
	const CompanyID old_company = _local_company;
	const auto old_start = _game_session_stats.start_time;
	_screen.width = _screen.pitch = 640;
	_screen.height = 480;
	ScreenSizeChanged();
	InitWindowSystem();
	_game_mode = GameMode::Normal;
	_switch_mode = SwitchMode::None;
	_local_company = CompanyID{0};
	REQUIRE(Vehicle::CanAllocateItem());
	Train *train = Vehicle::Create<Train>();
	train->SetFrontEngine();
	train->owner = CompanyID{0};
	train->tile = TileXY(8, 8);
	train->x_pos = train->y_pos = 8 * TILE_SIZE + 8;
	train->direction = Direction::SW;
	train->track = Track::X;
	train->vehstatus.Reset(VehState::Hidden);
	ShowCabViewWindow(train);
	Window *first = FindWindowById(WindowClass::VehicleCabView, train->index);
	REQUIRE(first != nullptr);
	ShowCabViewWindow(train);
	Window *second = FindWindowById(WindowClass::VehicleCabView, train->index);
	REQUIRE(second != nullptr);
	CHECK(second != first);
	_game_session_stats.start_time += std::chrono::milliseconds(1);
	second->OnRealtimeTick(0);
	CHECK(FindWindowById(WindowClass::VehicleCabView, train->index) == nullptr);
	_game_session_stats.start_time = old_start;
	ShowCabViewWindow(train);
	const VehicleID old_id = train->index;
	REQUIRE(FindWindowById(WindowClass::VehicleCabView, old_id) != nullptr);
	_vehicle_pool.CleanPool();
	CHECK(FindWindowById(WindowClass::VehicleCabView, old_id) == nullptr);
	REQUIRE(Vehicle::CanAllocateItem());
	Train *replacement = Vehicle::Create<Train>();
	REQUIRE(replacement->index == old_id);
	CHECK(FindWindowById(WindowClass::VehicleCabView, replacement->index) == nullptr);
	_vehicle_pool.CleanPool();
	UnInitWindowSystem();
	_game_session_stats.start_time = old_start;
	_local_company = old_company;
	_game_mode = old_mode;
	_switch_mode = old_switch;
	_screen = old_screen;
	DriverFactoryBase::SelectDriver("null", Driver::Type::Video);
}

TEST_CASE("Cab view masks foreign closed and unregistered tiles", "[cab-view]")
{
	SetupCabMap();
	TileIndex home = TileXY(8, 8);
	TileIndex gap = TileXY(21, 8);
	CHECK(CabViewTileVisible(home, INVALID_WORLD)); // ordinary OpenTTD map
	CHECK_FALSE(CabViewTileVisible(TileXY(0, 0), INVALID_WORLD));

	PlanetRegion a;
	a.id = WorldID{0};
	a.min_x = a.min_y = 1;
	a.max_x = a.max_y = 20;
	PlanetRegion b;
	b.id = WorldID{1};
	b.min_x = 22;
	b.max_x = 40;
	b.min_y = 1;
	b.max_y = 20;
	REQUIRE(PlanetManager::RegisterRegion(a));
	REQUIRE(PlanetManager::RegisterRegion(b));
	StellarNetwork::RegisterWorld({WorldID{0}, "home", "Home", 0, 0, true});
	StellarNetwork::RegisterWorld({WorldID{1}, "closed", "Closed", 10, 0, false});
	CHECK(CabViewTileVisible(home, WorldID{0}));
	CHECK_FALSE(CabViewTileVisible(TileXY(24, 8), WorldID{0}));
	CHECK_FALSE(CabViewTileVisible(TileXY(24, 8), WorldID{1}));
	CHECK_FALSE(CabViewTileVisible(gap, WorldID{0}));
	CHECK_FALSE(CabViewTileVisible(gap, INVALID_WORLD));
	PlanetManager::Reset();
	StellarNetwork::Reset();
}

TEST_CASE("Cab local gate snapshots follow authoritative transit arrival and backing", "[cab-view][gate]")
{
	const auto [entry, exit] = SetupCabLocalGate();
	const GameMode old_mode = _game_mode;
	const SwitchMode old_switch = _switch_mode;
	const CompanyID old_company = _local_company;
	_game_mode = GameMode::Normal;
	_switch_mode = SwitchMode::None;
	_local_company = CompanyID{0};
	REQUIRE(CabViewLocalGateVisible(entry, WorldID{0}));
	REQUIRE(CabViewLocalGateVisible(exit, WorldID{1}));
	CHECK_FALSE(CabViewLocalGateVisible(entry, WorldID{1}));
	REQUIRE(Vehicle::CanAllocateItem());
	Train *train = Vehicle::Create<Train>();
	train->SetFrontEngine();
	train->owner = CompanyID{0};
	train->direction = Direction::SW;
	train->tile = TileXY(8, 10);
	train->x_pos = 8 * TILE_SIZE + 8;
	train->y_pos = 10 * TILE_SIZE + 8;
	train->z_pos = 0;
	train->track = Track::X;
	train->vehstatus.Reset(VehState::Hidden);
	const auto approach = ResolveCabViewPresentation(train, CompanyID{0});
	REQUIRE(approach.phase == CabViewPhase::Scene);
	CHECK(approach.moving == train->GetMovingDirection());
	train->tile = entry;
	train->x_pos = TileX(entry) * TILE_SIZE + 8;
	train->y_pos = TileY(entry) * TILE_SIZE + 8;
	const auto visible_head = ResolveCabViewPresentation(train, CompanyID{0});
	CHECK(visible_head.phase == CabViewPhase::Scene);
	train->track = Track::Wormhole;
	train->vehstatus.Set(VehState::Hidden);
	PortalRegistry::SetVehicleTransitProgress(train->index, 0);
	const auto transit = ResolveCabViewPresentation(train, CompanyID{0});
	CHECK(transit.phase == CabViewPhase::LocalTransit);
	CHECK(CabViewTransitionRequiresReset(visible_head, transit));
	CHECK(CabViewTransitionResetsLook(visible_head, transit));
	train->tile = exit;
	train->x_pos = TileX(exit) * TILE_SIZE + 8;
	train->y_pos = TileY(exit) * TILE_SIZE + 8;
	train->track = Track::X;
	train->vehstatus.Reset(VehState::Hidden);
	const auto arrival = ResolveCabViewPresentation(train, CompanyID{0});
	CHECK(arrival.phase == CabViewPhase::Scene);
	CHECK(arrival.world == WorldID{1});
	CHECK(CabViewTransitionRequiresReset(transit, arrival));
	CHECK(CabViewTransitionRequiresReset(visible_head, arrival)); // hidden phase missed between GUI samples
	CHECK(CabViewTransitionResetsLook(visible_head, arrival));
	train->vehicle_flags.Set(VehicleFlag::DrivingBackwards);
	const auto backing = ResolveCabViewPresentation(train, CompanyID{0});
	CHECK(backing.moving == ReverseDir(train->direction));
	CHECK(CabViewTransitionRequiresReset(arrival, backing));
	train->vehicle_flags.Reset(VehicleFlag::DrivingBackwards);
	train->direction = Direction::NE;
	const auto turned = ResolveCabViewPresentation(train, CompanyID{0});
	CHECK(CabViewTransitionRequiresReset(arrival, turned));
	train->direction = Direction::SW;
	train->z_pos += 1;
	CHECK(CabViewTransitionRequiresReset(arrival, ResolveCabViewPresentation(train, CompanyID{0})));
	train->z_pos = 0;
	train->x_pos += 2 * TILE_SIZE + 1;
	CHECK(CabViewTransitionRequiresReset(arrival, ResolveCabViewPresentation(train, CompanyID{0})));
	CHECK(CabViewTransitionResetsLook(arrival, ResolveCabViewPresentation(train, CompanyID{0})));
	train->x_pos = TileX(exit) * TILE_SIZE + 8;
	train->owner = CompanyID{1};
	CHECK(ResolveCabViewPresentation(train, CompanyID{0}).phase == CabViewPhase::Unsupported);
	train->owner = CompanyID{0};
	_local_company = COMPANY_SPECTATOR;
	CHECK(ResolveCabViewPresentation(train, CompanyID{0}).phase == CabViewPhase::Unsupported);
	_local_company = CompanyID{0};
	StellarNetwork::RegisterWorld({WorldID{0}, "home", "Home", 0, 0, true});
	StellarNetwork::RegisterWorld({WorldID{1}, "other", "Other", 10, 0, false});
	CHECK(ResolveCabViewPresentation(train, CompanyID{0}).phase == CabViewPhase::Unsupported);
	CHECK_FALSE(CabViewLocalGateVisible(entry, WorldID{0}));
	PortalRegistry::Reset();
	_vehicle_pool.CleanPool();
	PlanetManager::Reset();
	StellarNetwork::Reset();
	_local_company = old_company;
	_game_mode = old_mode;
	_switch_mode = old_switch;
}

TEST_CASE("Cab gate rejects stale unlinked ordinary and external heads", "[cab-view][gate]")
{
	const auto [entry, exit] = SetupCabLocalGate();
	CHECK(CabViewLocalGateVisible(entry, WorldID{0}));
	PortalRegistry::UnregisterPortalByTile(entry);
	CHECK_FALSE(CabViewLocalGateVisible(entry, WorldID{0}));
	REQUIRE(PortalRegistry::RegisterUnlinkedGate(entry, DiagDirection::SW, WorldID{0}));
	CHECK_FALSE(CabViewLocalGateVisible(entry, WorldID{0}));
	PortalRegistry::Reset();
	REQUIRE(PortalRegistry::RegisterPortalPair(entry, DiagDirection::SW, WorldID{0},
		exit, DiagDirection::NE, WorldID{1}) != INVALID_PORTAL);
	MakeClear(exit, ClearGround::Grass, 0);
	CHECK(PortalRegistry::ClassifyGate(entry).kind == PortalGateKind::LocalStale);
	CHECK_FALSE(CabViewLocalGateVisible(entry, WorldID{0}));
	PortalRegistry::Reset();
	CHECK_FALSE(CabViewLocalGateVisible(entry, WorldID{0})); // ordinary unmanaged tunnel head
	MakeRailTunnel(exit, Owner{0}, DiagDirection::NE, RAILTYPE_BEGIN);
	REQUIRE(PortalRegistry::RegisterInterServerPortal(entry, DiagDirection::SW, WorldID{0}, WorldID{1}, 1) != INVALID_PORTAL);
	CHECK(PortalRegistry::ClassifyGate(entry).kind == PortalGateKind::ExternalLinked);
	CHECK_FALSE(CabViewLocalGateVisible(entry, WorldID{0}));
	PortalRegistry::Reset();
	PlanetManager::Reset();
	StellarNetwork::Reset();
}

TEST_CASE("Cab per-car mask checks both authoritative and coordinate worlds before sprites", "[cab-view][gate]")
{
	const auto [entry, exit] = SetupCabLocalGate();
	REQUIRE(Vehicle::CanAllocateItem());
	Train *car = Vehicle::Create<Train>();
	car->tile = TileXY(8, 10);
	car->x_pos = 8 * TILE_SIZE + 8;
	car->y_pos = 10 * TILE_SIZE + 8;
	car->track = Track::X;
	car->vehstatus.Reset(VehState::Hidden);
	CHECK(CabViewVehicleVisible(car, WorldID{0}));
	CHECK_FALSE(CabViewVehicleVisible(car, WorldID{1}));
	car->tile = exit;
	CHECK_FALSE(CabViewVehicleVisible(car, WorldID{0}));
	CHECK_FALSE(CabViewVehicleVisible(car, WorldID{1})); // coordinates still on world 0
	car->x_pos = TileX(exit) * TILE_SIZE + 8;
	car->y_pos = TileY(exit) * TILE_SIZE + 8;
	CHECK(CabViewVehicleVisible(car, WorldID{1}));
	car->vehstatus.Set(VehState::Hidden);
	CHECK_FALSE(CabViewVehicleVisible(car, WorldID{1}));
	car->vehstatus.Reset(VehState::Hidden);
	car->track = Track::Wormhole;
	car->tile = entry;
	CHECK_FALSE(CabViewVehicleVisible(car, WorldID{0}));
	StellarNetwork::RegisterWorld({WorldID{1}, "other", "Other", 10, 0, false});
	CHECK_FALSE(CabViewVehicleVisible(car, WorldID{1}));
	_vehicle_pool.CleanPool();
	PortalRegistry::Reset();
	PlanetManager::Reset();
	StellarNetwork::Reset();
}

TEST_CASE("Cab sprite collection preserves pending viewport state", "[cab-view]")
{
	SetupCabMap();
	CHECK(CabViewCollectorPreservesPendingStateForTest(TileXY(8, 8)));
	std::vector<GroundSpriteToDraw> ground;
	CollectTileGroundSprites(INVALID_TILE, ground);
	CHECK(ground.empty());
}

TEST_CASE("Cab CPU renderer sky output resizes without simulation mutation", "[.][cab-view][gui]")
{
	SetupCabMap();
	for (TileIndex tile{0}; tile < Map::Size(); ++tile) MakeVoid(tile);
	DrawPixelInfo *old_dpi = _cur_dpi;
	const auto old_random = _random;
	const auto old_date = TimerGameCalendar::date;
	Blitter *blitter = BlitterFactory::SelectBlitter("32bpp-simple");
	if (blitter != nullptr) {
		CabViewCamera camera;
		camera.x = camera.y = 8 * TILE_SIZE;
		camera.z = 8;
		camera.world = INVALID_WORLD;
		for (auto [w, h] : {std::pair{64, 40}, std::pair{72, 32}}) {
			std::vector<Colour> pixels(static_cast<size_t>(w) * h);
			DrawPixelInfo dpi{pixels.data(), 0, 0, w, h, w, ZoomLevel::Min};
			{
				AutoRestoreBackup screen_backup(_screen, dpi);
				AutoRestoreBackup dpi_backup(_cur_dpi, &dpi);
				AutoRestoreBackup anim_backup(_screen_disable_anim, true);
				DrawCabView3D({0, 0, w - 1, h - 1}, camera, static_cast<uint32_t>(w), 0);
			}
			CHECK(pixels.front().data != pixels.back().data);
			CHECK(pixels.front().data != 0);
		}
	}
	Blitter *palette_blitter = BlitterFactory::SelectBlitter("8bpp-simple");
	if (palette_blitter != nullptr) {
		constexpr int width = 64, height = 40;
		std::vector<uint8_t> pixels(width * height, 0xEE);
		DrawPixelInfo dpi{pixels.data(), 0, 0, width, height, width, ZoomLevel::Min};
		CabViewCamera camera;
		camera.x = camera.y = 8 * TILE_SIZE;
		camera.z = 8;
		{
			AutoRestoreBackup screen_backup(_screen, dpi);
			AutoRestoreBackup dpi_backup(_cur_dpi, &dpi);
			AutoRestoreBackup anim_backup(_screen_disable_anim, true);
			ResetCabView3D();
			DrawCabView3D({0, 0, width - 1, height - 1}, camera, 3, 0);
		}
		CHECK(std::ranges::any_of(pixels, [](uint8_t pixel) { return pixel != 0xEE; }));
	}
	_cur_dpi = old_dpi;
	ResetCabView3D();
	BlitterFactory::SelectBlitter("null");
	CHECK(blitter != nullptr);
	CHECK(palette_blitter != nullptr);
	CHECK(_random.state[0] == old_random.state[0]);
	CHECK(_random.state[1] == old_random.state[1]);
	CHECK(TimerGameCalendar::date == old_date);
	CHECK(IsTileType(TileXY(8, 8), TileType::Void));
}

TEST_CASE("Cab CPU renderer draws local terrain but masks foreign terrain and vehicles", "[.][cab-view][scene]")
{
	SetupCabMap();
	for (TileIndex tile{0}; tile < Map::Size(); ++tile) MakeVoid(tile);
	_searchpaths[Searchpath::BinaryDir] = std::filesystem::exists("build/lang/english.lng") ? "build/" : "./";
	_valid_searchpaths = {Searchpath::BinaryDir};
	InitializeLanguagePacks();
	SetMouseCursor(SPR_CURSOR_MOUSE, PAL_NONE);
	SetupCargoForClimate(LandscapeType::Temperate);
	_settings_game.game_creation.landscape = LandscapeType::Temperate;
	TimerGameCalendar::SetDate(TimerGameCalendar::ConvertYMDToDate(TimerGameCalendar::Year{1950}, 0, 1), 0);
	ResetHouses();
	InitializeBuildingCounts();
	ResetRoadTypes();
	/* The standard mock sprite cache has no backing SpriteFile. The CPU cab
	 * decoder intentionally reads raw graphics, so use the already installed
	 * base set in this isolated process instead of feeding it mock entries. */
	extern void DetermineBasePaths(std::string_view exe);
	const std::string test_binary = std::filesystem::absolute("openttd_test").string();
	DetermineBasePaths(test_binary);
	_valid_searchpaths.clear();
	for (Searchpath sp : EnumRange(Searchpath::End)) {
		if (!_searchpaths[sp].empty()) _valid_searchpaths.push_back(sp);
	}
	TarScanner::DoScan(TarScanner::Mode::Baseset);
	BaseGraphics::FindSets();
	REQUIRE(BaseGraphics::SetSet(nullptr));
	CabTestVideoDriverFactory video_factory;
	DriverFactoryBase::SelectDriver("cabtest", Driver::Type::Video);
	_engine_mngr.ResetToDefaultMapping();
	SetupEngines();
	GfxLoadSprites();
	Blitter *blitter = BlitterFactory::SelectBlitter("32bpp-simple");
	REQUIRE(blitter != nullptr);
	DrawPixelInfo *old_dpi = _cur_dpi;
	const DrawPixelInfo old_screen = _screen;
	const auto old_random = _random;
	const auto old_date = TimerGameCalendar::date;
	CabViewCamera camera;
	camera.x = camera.y = 8 * TILE_SIZE + 8;
	camera.z = 6;
	camera.yaw = 0;
	camera.world = INVALID_WORLD;
	constexpr int width = 96, height = 64;
	auto paint = [&](uint32_t frame) {
		std::vector<Colour> pixels(width * height);
		DrawPixelInfo dpi{pixels.data(), 0, 0, width, height, width, ZoomLevel::Min};
		/* The 32bpp blitter addresses rows through _screen.pitch even when
		 * _cur_dpi points at a private test buffer. Scope both globals. */
		{
			AutoRestoreBackup screen_backup(_screen, dpi);
			AutoRestoreBackup dpi_backup(_cur_dpi, &dpi);
			AutoRestoreBackup anim_backup(_screen_disable_anim, true);
			ResetCabView3D();
			DrawCabView3D({0, 0, width - 1, height - 1}, camera, frame, 0);
		}
		return pixels;
	};
	const auto sky = paint(1);
	PlanetRegion a;
	a.id = WorldID{0};
	a.min_x = a.min_y = 1;
	a.max_x = 12;
	a.max_y = 20;
	PlanetRegion b;
	b.id = WorldID{1};
	b.min_x = 13;
	b.max_x = 30;
	b.min_y = 1;
	b.max_y = 20;
	REQUIRE(PlanetManager::RegisterRegion(a));
	REQUIRE(PlanetManager::RegisterRegion(b));
	StellarNetwork::RegisterWorld({WorldID{0}, "home", "Home", 0, 0, true});
	StellarNetwork::RegisterWorld({WorldID{1}, "other", "Other", 0, 0, true});
	for (uint x = 1; x <= 12; ++x) for (uint y = 1; y <= 20; ++y) MakeClear(TileXY(x, y), ClearGround::Grass, 0);
	camera.world = WorldID{0};
	const auto local = paint(2);
	CHECK(local != sky);
	for (uint x = 13; x <= 30; ++x) for (uint y = 1; y <= 20; ++y) MakeClear(TileXY(x, y), ClearGround::Grass, 0);
	REQUIRE(Vehicle::CanAllocateItem());
	Train *foreign = Vehicle::Create<Train>();
	foreign->tile = TileXY(16, 8);
	foreign->x_pos = 16 * TILE_SIZE + 8;
	foreign->y_pos = 8 * TILE_SIZE + 8;
	foreign->vehstatus.Reset(VehState::Hidden);
	const auto masked = paint(3);
	CHECK(masked == local);
	/* The synthetic foreign vehicle has no engine image. Its mask has been
	 * exercised; remove it before looking from the destination world. */
	_vehicle_pool.CleanPool();
	/* This comparison goes through the real raw-base sprite decoder and CPU
	 * rasterizer. An unlinked physical head is suppressed; only an accessible
	 * LocalLinked head contributes the bounded opaque gate surface. */
	const TileIndex local_gate = TileXY(10, 8);
	const TileIndex remote_gate = TileXY(20, 8);
	MakeRailTunnel(local_gate, Owner{0}, DiagDirection::SW, RAILTYPE_BEGIN);
	MakeRailTunnel(remote_gate, Owner{0}, DiagDirection::NE, RAILTYPE_BEGIN);
	REQUIRE(IsTunnelTile(local_gate));
	const auto suppressed_head = paint(4);
	/* A cab already on each physical head must have local ground directly
	 * beneath its eye. Compare the lower central pixels at the exact same
	 * pose before and after linking, on both sides of the pair. */
	auto at_head = [&](TileIndex tile, WorldID world, int x_offset, float yaw, uint32_t frame) {
		camera.x = TileX(tile) * TILE_SIZE + x_offset;
		camera.y = TileY(tile) * TILE_SIZE + 8;
		camera.z = 4;
		camera.yaw = yaw;
		camera.world = world;
		return paint(frame);
	};
	/* The outbound NE pose matches the observed native x+4 mixed arrival.
	 * On the SW head use x+12 so twelve units of its tile lie ahead of the
	 * camera; the observed return at x+7 already sees the adjacent grass in
	 * this lower crop. Both views face AWAY from the gate frame, leaving the
	 * bounded local floor as the geometry under test. */
	const auto suppressed_arrival_a = at_head(local_gate, WorldID{0}, 12, static_cast<float>(M_PI), 10);
	const auto suppressed_arrival_b = at_head(remote_gate, WorldID{1}, 4, 0, 11);
	camera.x = camera.y = 8 * TILE_SIZE + 8;
	camera.z = 6;
	camera.yaw = 0;
	camera.world = WorldID{0};
	REQUIRE(PortalRegistry::RegisterPortalPair(local_gate, DiagDirection::SW, WorldID{0},
		remote_gate, DiagDirection::NE, WorldID{1}) != INVALID_PORTAL);
	CHECK(CabViewLocalGateVisible(local_gate, WorldID{0}));
	const auto local_gate_frame = paint(5);
	CHECK(local_gate_frame != suppressed_head);
	auto lower_changed = [&](const std::vector<Colour> &a, const std::vector<Colour> &b) {
		uint changed = 0;
		for (int y = height - 12; y < height; ++y) {
			for (int x = width / 4; x < 3 * width / 4; ++x) {
				if (a[static_cast<size_t>(y) * width + x] != b[static_cast<size_t>(y) * width + x]) ++changed;
			}
		}
		return changed;
	};
	const auto linked_arrival_a = at_head(local_gate, WorldID{0}, 12, static_cast<float>(M_PI), 12);
	const auto linked_arrival_b = at_head(remote_gate, WorldID{1}, 4, 0, 13);
	CHECK(lower_changed(linked_arrival_a, suppressed_arrival_a) >= 48);
	CHECK(lower_changed(linked_arrival_b, suppressed_arrival_b) >= 48);
	camera.x = camera.y = 8 * TILE_SIZE + 8;
	camera.z = 6;
	camera.yaw = 0;
	camera.world = WorldID{0};
	StellarNetwork::RegisterWorld({WorldID{1}, "other", "Other", 0, 0, false});
	CHECK_FALSE(CabViewLocalGateVisible(local_gate, WorldID{0}));
	const auto inaccessible_gate = paint(6);
	CHECK(inaccessible_gate == suppressed_head);
	CHECK(_random.state[0] == old_random.state[0]);
	CHECK(_random.state[1] == old_random.state[1]);
	CHECK(TimerGameCalendar::date == old_date);
	_vehicle_pool.CleanPool();
	PortalRegistry::Reset();
	PlanetManager::Reset();
	StellarNetwork::Reset();
	_cur_dpi = old_dpi;
	_screen = old_screen;
	ResetCabView3D();
	BlitterFactory::SelectBlitter("null");
	DriverFactoryBase::SelectDriver("null", Driver::Type::Video);
}
