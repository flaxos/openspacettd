#!/usr/bin/env python3
"""Prove local gate cab transitions and cold reload in private SDL processes.

Requires an existing WITH_CAB_VIEW build, SDL offscreen and installed OpenGFX.
The supplied disposable WP11 save is copied, never edited. No build, download,
owner display, federation connection or human UAT is part of this proof.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import time

from PIL import Image, ImageChops

from test_commonwealth_platform_art import ROOT, configuration, profile_environment


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def no_core_dump():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def compare_normal_viewport(output, phase):
    names = [f"gate_{phase}_normal_before_reopen.png",
             f"gate_{phase}_normal_after_reopen_close.png"]
    result = {"passed": False, "screenshots": names,
              "region_reason": "Main viewport below the 22-pixel toolbar; same paused endpoint and scroll position."}
    try:
        with Image.open(output / names[0]) as first, Image.open(output / names[1]) as second:
            if first.size != second.size or first.width != 1280 or first.height != 800:
                result["error"] = "Unexpected or different native screenshot dimensions"
                return result
            region = (0, 22, first.width, first.height)
            difference = ImageChops.difference(first.convert("RGB").crop(region),
                                              second.convert("RGB").crop(region))
            result["region"] = region
            result["difference_bbox_in_region"] = difference.getbbox()
            result["changed_pixels"] = sum(pixel != (0, 0, 0) for pixel in difference.getdata())
            result["passed"] = result["changed_pixels"] == 0
    except (OSError, ValueError) as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def run_phase(binary, source, output, phase, expected=None):
    output.mkdir(parents=True, exist_ok=False)
    save = output / "fixture-copy.sav"
    shutil.copyfile(source, save)
    config = configuration(output)
    config.write_text(config.read_text().replace("[gui]\n", "[gui]\nerrmsg_duration = 0\n"))
    (output / "scripts").mkdir()
    (output / "scripts/game_start.scr").write_text("cab_gate_native_start\n")
    env = {**os.environ, **profile_environment(output), "SDL_VIDEODRIVER": "offscreen",
           "SDL_RENDER_DRIVER": "software", "OPENSPACETTD_WORLD_COUNT": "3",
           "OSTTD_CAB_NATIVE_CONFIG": str(config), "OSTTD_CAB_NATIVE_SAVE": str(save),
           "OSTTD_CAB_NATIVE_OUTPUT": str(output), "OSTTD_CAB_NATIVE_BINARY": str(binary),
           "OSTTD_CAB_GATE_PHASE": phase}
    for key in ("DISPLAY", "WAYLAND_DISPLAY", "OSTTD_CAB_GATE_EXPECTED"):
        env.pop(key, None)
    if expected is not None:
        env["OSTTD_CAB_GATE_EXPECTED"] = str(expected)
    baseset = Path(env["XDG_DATA_HOME"]) / "openttd/baseset"
    if baseset.is_symlink():
        baseset.unlink()  # Only this run's newly created profile symlink.
    baseset.mkdir(exist_ok=True)
    installed = Path("/usr/share/games/openttd/baseset/opengfx")
    if not installed.is_dir():
        raise RuntimeError("Installed OpenGFX unavailable; no download attempted")
    (baseset / "opengfx").symlink_to(installed, target_is_directory=True)
    command = [str(binary), "Native SDL local gate cab round trip and cold reload"]
    report = {"passed": False, "phase": phase, "command": command,
              "source_save": str(source), "source_save_sha256": sha256(source),
              "binary_sha256": sha256(binary), "config_sha256": sha256(config),
              "display": "SDL offscreen / software", "human_uat": "Pending",
              "hard_timeout_seconds": 240, "minimum_free_bytes": 100 * 1024 * 1024,
              "content_sha256": {str(p): sha256(p) for p in sorted(installed.iterdir()) if p.is_file()},
              "newgrf_sha256": {str(p): sha256(p) for p in sorted((ROOT / "bin/newgrf").glob("*.grf"))}}
    started = time.monotonic()
    with (output / "native-process.log").open("x") as log:
        process = subprocess.Popen(command, cwd=output, env=env, stdin=subprocess.DEVNULL,
                                   stdout=log, stderr=subprocess.STDOUT, preexec_fn=no_core_dump)
        try:
            while process.poll() is None:
                if time.monotonic() - started > 240:
                    report["error"] = "Native process exceeded 240-second hard stop"
                    process.kill()
                    break
                if shutil.disk_usage(output).free < report["minimum_free_bytes"]:
                    report["error"] = "Stopped own native process below 100 MiB free disk reserve"
                    process.kill()
                    break
                time.sleep(0.1)
            process.wait()
            report["exit_code"] = process.returncode
            manifest = output / "gate-native-manifest.json"
            if manifest.is_file():
                report["native_manifest"] = json.loads(manifest.read_text())
            report["passed"] = process.returncode == 0 and report.get("native_manifest", {}).get("passed") is True
            calls = report.get("native_manifest", {}).get("explicit_state_game_loop_calls")
            report["explicit_call_limit"] = 16384 if phase == "roundtrip" else 8192
            report["explicit_call_budget_valid"] = (type(calls) is int and
                                                    0 < calls <= report["explicit_call_limit"])
            report["passed"] = report["passed"] and report["explicit_call_budget_valid"]
            report["normal_viewport_comparison"] = compare_normal_viewport(output, phase)
            report["passed"] = report["passed"] and report["normal_viewport_comparison"]["passed"]
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
            report["elapsed_seconds"] = time.monotonic() - started
            report["source_save_unchanged"] = sha256(source) == report["source_save_sha256"]
            report["copy_sha256_after"] = sha256(save)
            report["screenshots"] = {p.name: {"bytes": p.stat().st_size, "sha256": sha256(p)} for p in sorted(output.glob("*.png"))}
            report["passed"] = report["passed"] and report["source_save_unchanged"]
            (output / "runner-evidence.json").write_text(json.dumps(report, indent=2) + "\n")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--save", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path, help="New evidence directory")
    parser.add_argument("--test-binary", type=Path, default=ROOT / "build/openttd_test")
    args = parser.parse_args()
    source = args.save.resolve(strict=True)
    binary = args.test_binary.resolve(strict=True)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    report = {"passed": False, "phases": [], "source_save_sha256": sha256(source)}
    try:
        first = run_phase(binary, source, output / "roundtrip", "roundtrip")
        report["phases"].append(first)
        if not first["passed"]:
            raise RuntimeError("Initial native round trip failed; cold phase not started")
        checkpoint = output / "roundtrip/gate-checkpoint.sav"
        expected = output / "roundtrip/gate-checkpoint.json"
        if not checkpoint.is_file() or not expected.is_file():
            raise RuntimeError("Initial proof omitted its native save or frozen comparison snapshot")
        report["checkpoint_sha256"] = sha256(checkpoint)
        report["expected_snapshot_sha256"] = sha256(expected)
        cold = run_phase(binary, checkpoint, output / "cold", "cold", expected)
        report["phases"].append(cold)
        report["explicit_state_game_loop_calls"] = sum(
            p.get("native_manifest", {}).get("explicit_state_game_loop_calls", 0)
            for p in report["phases"])
        report["combined_explicit_call_limit"] = 24576
        report["passed"] = cold["passed"] and report["explicit_state_game_loop_calls"] <= 24576
    except (RuntimeError, OSError, ValueError) as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        report["source_save_unchanged"] = sha256(source) == report["source_save_sha256"]
        report["passed"] = report["passed"] and report["source_save_unchanged"]
        (output / "gate-runner-evidence.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"passed": report["passed"], "completed_phases": len(report["phases"]),
                      "source_save_unchanged": report["source_save_unchanged"], "error": report.get("error")}))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
