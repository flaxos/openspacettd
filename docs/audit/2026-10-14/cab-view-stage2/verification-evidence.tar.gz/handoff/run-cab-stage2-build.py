import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

root = Path(__file__).parent / "openspacettd-cabview"
log = root / "build/agent-logs" / (sys.argv[1] + ".log")
record_path = log.with_suffix(".json")
if log.exists() or record_path.exists():
    raise SystemExit("Refusing to overwrite evidence")
command = sys.argv[2:]
minimum = 100 * 1024 * 1024
assert command and shutil.disk_usage(root).free >= minimum

def child_limits():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

start = time.monotonic()
record = {"command": command, "minimum_free_bytes": minimum,
          "starting_free_bytes": shutil.disk_usage(root).free}
with log.open("x") as output:
    process = subprocess.Popen(command, cwd=root, stdout=output,
                               stderr=subprocess.STDOUT, start_new_session=True,
                               preexec_fn=child_limits)
    try:
        while process.poll() is None:
            if shutil.disk_usage(root).free < minimum:
                record["error"] = "Free disk fell below 100 MiB"
                os.killpg(process.pid, signal.SIGTERM)
                break
            if time.monotonic() - start > 1800:
                record["error"] = "Build exceeded 1800-second limit"
                os.killpg(process.pid, signal.SIGTERM)
                break
            time.sleep(1)
        process.wait(timeout=20)
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
record.update(exit_code=process.returncode, elapsed_seconds=time.monotonic()-start,
              ending_free_bytes=shutil.disk_usage(root).free)
record_path.write_text(json.dumps(record, indent=2) + "\n")
print("\n".join(log.read_text(errors="replace").splitlines()[-12:]))
print(json.dumps(record))
raise SystemExit(process.returncode or (1 if "error" in record else 0))
