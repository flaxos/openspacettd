import json, pathlib, re, subprocess, sys, time
root = pathlib.Path(__file__).parent / "openspacettd-cabview"
name = sys.argv[1]
log = root / "build/agent-logs" / (name + ".log")
if log.exists(): raise SystemExit("Refusing to overwrite evidence")
j = json.loads(subprocess.check_output(["ctest", "--test-dir", str(root / "build"), "--show-only=json-v1"], text=True))
names = [t["name"] for t in j["tests"] if t["name"].startswith(("Cab", "PortalRegistry", "Portal Wormhole", "ConsistTraversal", "Planet SaveLoad", "PortalGateSprites", "Stellar activation", "Tooltips_reject")) or "classification separates local" in t["name"]]
regex = "^(" + "|".join(re.escape(n) for n in names) + ")$"
command = ["ctest", "--test-dir", str(root / "build"), "-j1", "--timeout", "120", "-V", "-R", regex]
started = time.monotonic()
with log.open("x") as f:
    result = subprocess.run(command, cwd=root, stdout=f, stderr=subprocess.STDOUT)
text = log.read_text(errors="replace")
valid = "100% tests passed" in text and "No tests were found" not in text and "Error in compile" not in text
record = {"valid_execution": valid, "command": command, "selected_tests": names, "returncode": result.returncode, "seconds": time.monotonic()-started}
log.with_suffix(".json").write_text(json.dumps(record, indent=2)+"\n")
print("\n".join(log.read_text(errors="replace").splitlines()[-18:]))
print("selected", len(names), "exit", result.returncode)
raise SystemExit(result.returncode if result.returncode else (0 if valid else 2))
