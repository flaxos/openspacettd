Stage 2 native-controller review — BLOCKED / uncompiled source
Reviewer: Astra; read-only. No source changes, builds or launches during review.

File: openspacettd-cabview/src/tests/test_cab_view_gate_native.cpp

1. Lines 46–47: file-scope TileXY runs before map dimensions exist. Resolve gate coordinates after loading.
2. Lines 160–167,429: Capture and the traversal loop both schedule callbacks. A duplicate callback can collect a screenshot before it executes; one scheduling owner is required.
3. Line279: StartPass resets pass_calls after warmup. Warmup must count within the first8192-call limit and combined24576-call proof budget.
4. Lines300–304: arrival captures and returns before inspecting simultaneous mixed-world occupancy, risking loss of the short-lived state. Inspect both in the same sample.
5. Lines304–320,402: helper-mask checks and an unconditional recovery boolean do not prove actual rendered suppression or viewport pixel equality.
6. Lines51–57: order snapshot omits non-stop, stopping-location and timetable flags; full-order equality is not established.

Existing focused regressions:33/36 passed. Two synthetic train fixtures leave direction invalid; linked-gate pixel equality failure remains unresolved. Stage2 is not accepted. Direct user approval remains pending following two automatic-review rejections of the fixture launch.

