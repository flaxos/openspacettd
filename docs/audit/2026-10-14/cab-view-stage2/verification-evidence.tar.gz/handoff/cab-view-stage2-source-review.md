# Stage 2 cab source review — 14 October 2026

Independent Astra review of the presentation-only Stage 2 delta in
`openspacettd-cabview`, against the canonical active plan. This note is a source
checkpoint for later packaging, not runtime acceptance or a competing handoff.

**Result: clear after two compile defects were corrected.** Initial accesses to
the train-only `track` field through `const Vehicle *` were invalid. The GUI now
casts after checking the Train type; the generic vehicle visibility helper guards
its cast with `VehicleType::Train`. No build was run by this reviewer.

Reviewed source boundaries:

- `src/cab_view_gui.cpp`: local gate classification verifies both physical heads,
  endpoint world metadata and actual accessible map regions; hidden local transit
  produces opaque status only. Actual moving direction handles backing. Phase,
  world, position, direction and height changes reset before subsequent rendering.
- `src/cab_view_3d.cpp`: the local gate path precedes generic tunnel suppression
  and creates bounded local geometry without destination scene collection or
  ordinary tunnel reconstruction. Per-car tile and coordinate world checks run
  before sprite lookup; hidden/wormhole train units are omitted.
- `src/cab_view.h`, `src/cab_view_3d.h`, `src/lang/english.txt`,
  `src/tests/test_cab_view.cpp`: presentation snapshots, transient state and focused
  boundary tests remain separate from native movement and persistent state.
- `scripts/test_cab_view_gate_native.py`: copied input saves, private config/data
  trees, SDL offscreen selection, timeout and free-space guards retain isolation.

No material privacy, lifecycle or simulation-boundary defect found in the
reviewed production delta. The tests establish resolver/predicate behavior and
actual gate-render suppression. Native local traversal, mixed-world consist
pixels, frozen cold-reload comparison and the forthcoming native controller
still require separate review. Human UAT, cross-platform support, performance,
federation continuation and full gate-art fidelity are not accepted by this note.

The later four-car depot-fixture refinement is recorded in the active plan. It
does not itself constitute executed evidence, and setup advances consume the
existing first-pass budget. No production edits, builds or native runs were made
by the reviewer.
