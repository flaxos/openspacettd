#!/usr/bin/env python3
"""Bounded disposable native WP11 fixture for the Stage 1 cab proof."""
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent / "openspacettd-cabview"
sys.path.insert(0, str(ROOT / "scripts"))
from test_commonwealth_platform_art import ProfileEngine, configuration, snapshot

out = ROOT / "build/cab-native" / sys.argv[1]
out.mkdir(parents=True, exist_ok=False)
config = configuration(out)
started = time.monotonic()
report = {"passed": False, "scope": "Disposable WP11 rendering fixture; assisted starting cash is not balance evidence.", "native_advances_requested": 0}
engine = None
try:
    engine = ProfileEngine(ROOT / "build/openttd", config, out, "prepare", seed=11)
    engine.command("wp11_slice prepare", "WP11 prepared")
    engine.command("wp11_slice build", "WP11 built")
    report["initial"] = snapshot(engine)
    report["native_advances_requested"] = 1
    report["advance"] = engine.advance()
    report["final"] = snapshot(engine)
    engine.save(out / "cab-native-fixture.sav")
    report["passed"] = True
except BaseException as exc:
    report["error"] = f"{type(exc).__name__}: {exc}"
    raise
finally:
    if engine is not None:
        engine.close()
    report["elapsed_seconds"] = time.monotonic() - started
    report["sha256"] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in [config, *out.glob("*.sav")]}
    (out / "fixture-evidence.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: report[k] for k in ["passed", "elapsed_seconds", "native_advances_requested"]}))
