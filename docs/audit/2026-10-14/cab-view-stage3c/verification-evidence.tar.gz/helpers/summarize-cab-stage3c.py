"""Summarize one declared diagnostic; this does not replace any acceptance matrix."""
import hashlib,json,math,statistics,sys
from pathlib import Path
root=Path(__file__).parent/'openspacettd-cabview'
run=Path(sys.argv[1]);run=run if run.is_absolute() else root/run
out=Path(sys.argv[2]);out=out if out.is_absolute() else root/out
assert not out.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def stats(values):
    return {'count':len(values),'min_us':min(values),'median_us':statistics.median(values),
            'p95_us':sorted(values)[math.ceil(len(values)*.95)-1],'max_us':max(values)}
r=json.loads((run/'gate-runner-evidence.json').read_text())
assert r['passed'] and len(r['phases'])==2
phase=r['phases'][1];assert phase['stage3c_validation']['passed']
d=phase['native_manifest']['stage3c_diagnostic'];timing=d['timing'];palette=d['vehicle_palette_preflight']
rows=[];blocks=[]
for b in timing['blocks']:
    for ordinal,s in enumerate(b['samples']):
        row={'block':b['index'],'mode':b['mode'],'ordinal_in_block':ordinal,**s}
        row['wall_minus_stages_us']=s['wall_us']-sum(s['frame'][key] for key in ('prepare_us','raster_us','effect_us','output_us'))
        rows.append(row)
    counters=None
    if b['before']['supported'] and b['after']['supported']:
        counters={key:b['after'][key]-b['before'][key] for key in ('user_cpu_us','system_cpu_us','voluntary_context_switches','involuntary_context_switches')}
    blocks.append({'index':b['index'],'mode':b['mode'],'relative_start_us':b['relative_start_us'],
                   'wall':stats([s['wall_us'] for s in b['samples']]),'process_counter_deltas':counters})
by_mode={}
for mode in ('off','reduced'):
    samples=[r for r in rows if r['mode']==mode]
    by_mode[mode]={'wall':stats([s['wall_us'] for s in samples]),
                   'stage_distributions':{key:stats([s['frame'][key] for s in samples]) for key in ('prepare_us','raster_us','effect_us','output_us')},
                   'largest_correlated_frames':sorted(samples,key=lambda s:s['wall_us'],reverse=True)[:8]}
retained=json.loads((root/'build/cab-stage3c-candidate/retained-timing-analysis.json').read_text())
old_path=root/'build/cab-stage3b-candidate/matrix-01/repeat-01/cold/gate-native-manifest.json'
old=json.loads(old_path.read_text());old_cell=next(c for c in old['profiles'] if c['capture_label']=='back_arrival_mixed' and c['mode']=='off' and c['view_width']==640)
pose=timing['pose'];old_pose=old_cell['pose']
comparisons={'frozen_snapshot_exact':timing['frozen_snapshot']==old_cell['frozen_snapshot'],
             'canonical_palette_exact':timing['canonical_palette_rgba']==old_cell['palette_rgba'],
             'pose_exact':all(pose[key]==old_pose[key] for key in ('x','y','z','tile','moving')) and pose['yaw']==old_pose['camera_yaw'],
             'world_exact':pose['world']==old_cell['selected_world'],
             'cache_exact':timing['blocks'][0]['cache']==old_cell['cache']}
comparisons["historical_frozen_differing_fields"] = [k for k in sorted(set(timing["frozen_snapshot"]) | set(old_cell["frozen_snapshot"])) if timing["frozen_snapshot"].get(k) != old_cell["frozen_snapshot"].get(k)]
assert all(comparisons[k] for k in ("canonical_palette_exact", "pose_exact", "world_exact", "cache_exact")),comparisons
oldimage=old_path.parent/old_cell['diagnostic_image'];newimage=run/'cold'/timing['blocks'][0]['image']
comparisons['image_sha256_exact']=sha(oldimage)==sha(newimage);assert comparisons['image_sha256_exact']
layer_counts={};raw=eligible=0;indices=set();query_count=0
for car in palette['cars']:
    for direction in car['directions']:
        query_count+=1;n=direction['raw_sequence_count'];layer_counts[str(n)]=layer_counts.get(str(n),0)+1
        raw+=direction['raw_animated_pixels'];eligible+=direction['eligible_source_contributions']
        for layer in direction['layers']:
            indices.update(227+i for i,n in enumerate(layer['eligible_slot_counts_227_254']) if n)
report={'status':'Bounded diagnostic complete; this is not acceptance of real SpriteStack or animated vehicle palettes',
        'binary_sha256':phase['binary_sha256'],'run_report_sha256':sha(run/'gate-runner-evidence.json'),
        'counterbalanced_order':timing['block_order'],'sample_count':len(rows),'by_mode':by_mode,'blocks':blocks,
        'descriptive_reduced_minus_off':{key:by_mode['reduced']['wall'][key]-by_mode['off']['wall'][key] for key in ('median_us','p95_us')},
        'historical_comparison':comparisons,'retained_stage3b':retained['matrix_summary'],
        'retained_failed_budget_us':500,'retained_failed_added_p95_us':1114,
        'palette_preflight':{'visible_cars':palette['visible_car_count'],'direction_queries':query_count,'sequence_counts':layer_counts,
                             'scan_complete':palette['scan_complete'],'candidate_actual_sw':palette['candidate_actual_sw'],
                             'candidate_other_direction':palette['candidate_other_direction'],'raw_animated_pixels':raw,
                             'eligible_source_contributions':eligible,'used_animated_indices':sorted(indices),
                             'negative_scope':palette['negative_scope']},
        'source_save_unchanged':r['source_save_unchanged'],'explicit_state_game_loop_calls':r['explicit_state_game_loop_calls'],
        'sampled_process_memory_kib':phase.get('sampled_process_memory_kib'),
        'limits':['Single diagnostic, one Linux machine and one fixture; no acceptance rerun or interactive FPS claim',
                  'Process counter deltas include comparisons, copies and cache scans; not render-only CPU usage or per-frame causality',
                  'No CPU frequency, scheduler trace, allocator trace or per-worker timing; original failure cause remains unproven',
                  'A negative palette scan is bounded to current fixture engines, cargo/livery state and directions, not all installed stock',
                  'Real SpriteStack content, observed animated vehicle colours, human UAT and other platforms remain unqualified']}
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('status','sample_count','descriptive_reduced_minus_off','historical_comparison','palette_preflight')}))
