import json
import math
import statistics
import sys
from pathlib import Path

root = Path(__file__).parent / 'openspacettd-cabview'
paths = [Path(p) for p in sys.argv[2:]]
output = Path(sys.argv[1])
if output.exists():
    raise SystemExit('Refusing to overwrite evidence')

def stats(values):
    values = sorted(values)
    return {'minimum_us': values[0], 'median_us': statistics.median(values),
            'p95_us': values[math.ceil(len(values) * .95) - 1],
            'maximum_us': values[-1], 'samples': len(values)}

result = {'runs': [], 'comparison_groups': []}
groups = {}
for path in paths:
    report = json.loads(path.read_text())
    assert report['passed'], path
    run = {'path': str(path), 'passed': report['passed'], 'explicit_calls': report['explicit_state_game_loop_calls'], 'phases': []}
    for phase in report['phases']:
        native = phase['native_manifest']
        item = {key: phase[key] for key in ('phase', 'binary_sha256', 'machine', 'sampled_process_memory_kib', 'profile_validation', 'normal_viewport_comparison')}
        item.update({key: native.get(key) for key in ('base_graphics', 'active_grfs', 'active_blitter', 'active_blitter_depth')})
        item['cells'] = []
        for cell in native['profiles']:
            entry = {key: cell[key] for key in ('capture_label', 'phase', 'view_width', 'view_height', 'selected_world', 'pose', 'cache')}
            entry['gate'] = cell.get('gate')
            entry['cold_sample'] = cell['cold_sample']
            entry['cached_sample'] = cell.get('cached_sample')
            entry['wall'] = stats([sample['external_total_us'] for sample in cell['samples']])
            if cell['phase'] == 'scene':
                entry['renderer'] = {key: stats([sample['renderer'][key] for sample in cell['samples']]) for key in ('prepare_us', 'raster_us', 'effect_us', 'output_us', 'total_us')}
                entry['geometry'] = {key: sorted(set(sample['renderer'][key] for sample in cell['samples'])) for key in ('visible_tiles', 'triangles', 'threads', 'scale')}
            item['cells'].append(entry)
            key = (phase['phase'], cell['capture_label'], cell['view_width'], cell['view_height'])
            groups.setdefault(key, []).append(entry)
        run['phases'].append(item)
    result['runs'].append(run)
for key, entries in sorted(groups.items()):
    medians = [e['wall']['median_us'] for e in entries]
    result['comparison_groups'].append({'phase': key[0], 'label': key[1], 'width': key[2], 'height': key[3],
        'same_pose': all(e['pose'] == entries[0]['pose'] and e['selected_world'] == entries[0]['selected_world'] for e in entries),
        'warm_medians_us': medians, 'warm_p95_us': [e['wall']['p95_us'] for e in entries],
        'median_spread_us': max(medians) - min(medians),
        'cold_wall_us': [e['cold_sample']['external_total_us'] for e in entries]})
result['notes'] = [
    'Fixed-scale private renderer timings, not interactive FPS. Renderer construction/shared immutable table setup outside Draw are excluded from frame samples.',
    'Caches are per cell. Native shared sprite-cache warming can occur. Cached samples retain counts from the previously built scene; no geometry is rebuilt.',
    'Memory counts retained vector capacities only, excluding container nodes, fixed object storage and allocator overhead. Process RSS/high-water is separately sampled.',
    'Transit uses actual opaque widget rendering, without scene collection or rasterization.']
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result['comparison_groups'], indent=2))
