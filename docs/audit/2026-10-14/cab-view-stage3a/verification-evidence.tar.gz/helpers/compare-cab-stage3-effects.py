"""Compare three matched native mode profiles with the frozen Stage 3A budget."""
import json
import math
import statistics
import sys
from pathlib import Path


def describe(values):
    values = sorted(values)
    return {'median_us': statistics.median(values),
            'p95_us': values[math.ceil(len(values) * .95) - 1],
            'minimum_us': values[0], 'maximum_us': values[-1]}


def load_cells(path, candidate):
    report = json.loads(path.read_text())
    assert report['passed'], path
    cells = {}
    for phase in report['phases']:
        for cell in phase['native_manifest']['profiles']:
            mode = cell['mode'] if candidate else 'off'
            key = (phase['phase'], cell['capture_label'], cell['view_width'], cell['view_height'], mode)
            assert key not in cells, key
            stats = {'wall': describe([s['external_total_us'] for s in cell['samples']]),
                     'cold_wall_us': cell['cold_sample']['external_total_us'],
                     'cached_sample': cell.get('cached_sample'), 'pose': cell['pose'],
                     'world': cell['selected_world'], 'cache': cell.get('cache')}
            if cell['phase'] == 'scene':
                stats['stages'] = {field: describe([s['renderer'][field] for s in cell['samples']])
                                   for field in ('prepare_us', 'raster_us', 'effect_us', 'output_us', 'total_us')}
                stats['effect'] = stats['stages']['effect_us']
            elif candidate:
                stats['effect'] = describe([s['effect_us'] for s in cell['samples']])
            else:
                stats['effect'] = describe([0] * 100)
            cells[key] = stats
    return report, cells


output = Path(sys.argv[1])
root = Path(__file__).parent / 'openspacettd-cabview'
paths = [Path(p) for p in sys.argv[2:]]
assert len(paths) == 3 and not output.exists()
runs = [load_cells(path, True) for path in paths]
baselines = [load_cells(root / f'build/cab-stage3-baseline/near-repeat-{i:02d}/gate-runner-evidence.json', False) for i in (1, 2, 3)]
groups = sorted({key[:4] for key in runs[0][1]})
result = {'candidate_paths': [str(p) for p in paths], 'groups': [], 'passed_effect_budget': True,
          'off_regression_investigations': [], 'notes': [
              'Median of three matched-repeat deltas and ratios; all raw repeats retained.',
              'Each mode has a fresh renderer context. Cold frame costs remain separate.',
              'Fixed-scale diagnostic timings are not interactive FPS or comfort evidence.']}
for group in groups:
    entry = {'phase': group[0], 'label': group[1], 'width': group[2], 'height': group[3], 'modes': {}}
    off = [cells[group + ('off',)] for _, cells in runs]
    base = [cells[group + ('off',)] for _, cells in baselines]
    assert all(a['pose'] == b['pose'] and a['world'] == b['world'] for a, b in zip(off, base)), group
    off_delta = [a['wall']['median_us'] - b['wall']['median_us'] for a, b in zip(off, base)]
    off_allowance = max(250, .1 * statistics.median([b['wall']['median_us'] for b in base]))
    entry['off_baseline_delta_medians_us'] = off_delta
    entry['off_baseline_delta_median_us'] = statistics.median(off_delta)
    entry['off_investigate_threshold_us'] = off_allowance
    if statistics.median(off_delta) > off_allowance:
        result['off_regression_investigations'].append(list(group))
    for mode in ('off', 'reduced', 'full'):
        values = [cells[group + (mode,)] for _, cells in runs]
        for a, b in zip(values, off):
            assert a['pose'] == b['pose'] and a['world'] == b['world'], (group, mode)
        delta = [a['wall']['median_us'] - b['wall']['median_us'] for a, b in zip(values, off)]
        tail_delta = [a['wall']['p95_us'] - b['wall']['p95_us'] for a, b in zip(values, off)]
        ratios = [a['wall']['median_us'] / b['wall']['median_us'] for a, b in zip(values, off)]
        direct = [a['effect']['median_us'] for a in values]
        direct_tail = [a['effect']['p95_us'] for a in values]
        row = {'repeats': values, 'added_median_us_by_repeat': delta,
               'added_p95_us_by_repeat': tail_delta, 'median_total_ratio_by_repeat': ratios,
               'median_added_us': statistics.median(delta), 'median_added_p95_us': statistics.median(tail_delta),
               'median_total_ratio': statistics.median(ratios),
               'median_direct_effect_us': statistics.median(direct),
               'median_direct_effect_p95_us': statistics.median(direct_tail)}
        if mode == 'off':
            passed = all(a == 0 for a in direct + direct_tail)
        else:
            allowance, tail = (1000, 2000) if mode == 'full' else (250, 500)
            passed = max(row['median_added_us'], row['median_direct_effect_us']) <= allowance
            passed = passed and max(row['median_added_p95_us'], row['median_direct_effect_p95_us']) <= tail
            if mode == 'full' and not group[1].endswith('transit'):
                passed = passed and row['median_total_ratio'] <= 1.35
        row['passed_effect_budget'] = passed
        result['passed_effect_budget'] = result['passed_effect_budget'] and passed
        entry['modes'][mode] = row
    result['groups'].append(entry)
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed_effect_budget': result['passed_effect_budget'],
                  'off_regression_investigations': result['off_regression_investigations'],
                  'failed_modes': [{'phase': g['phase'], 'label': g['label'], 'width': g['width'], 'mode': m}
                                   for g in result['groups'] for m, data in g['modes'].items()
                                   if not data['passed_effect_budget']]}, indent=2))
