import hashlib
import json
import sys
from pathlib import Path

root = Path(__file__).parent / 'openspacettd-cabview'
mode = sys.argv[1]
assert mode in ('off', 'on')
out = root / f'build/agent-logs/stage3-final-{mode}-manifest.json'
assert not out.exists()
cache = (root / 'build/CMakeCache.txt').read_text()
assert f'WITH_CAB_VIEW:BOOL={mode.upper()}' in cache
commands = json.loads((root / 'build/compile_commands.json').read_text())
units = sorted({r['file'] for r in commands if 'cab_view' in Path(r['file']).name})
definitions = sorted({r['file'] for r in commands if '-DWITH_CAB_VIEW' in r['command']})
assert (len(units), len(definitions)) == ((0, 0) if mode == 'off' else (5, 11))
record = {'configuration': mode.upper(), 'cab_compile_units': units,
          'feature_definitions': definitions, 'binary_hashes': {},
          'compiler': 'g++ 13.3.0', 'build_type': 'Release',
          'with_assert_defined': all('-DWITH_ASSERT' in r['command'] for r in commands if r['file'].endswith('/openttd.cpp'))}
assert any(r['file'].endswith('/openttd.cpp') for r in commands)
for name in ('openttd', 'openttd_test', 'lang/english.lng'):
    record['binary_hashes'][name] = hashlib.sha256((root / 'build' / name).read_bytes()).hexdigest()
out.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
