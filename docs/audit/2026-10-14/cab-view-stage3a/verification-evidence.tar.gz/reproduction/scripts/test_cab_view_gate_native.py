#!/usr/bin/env python3
"""Prove local gate cab transitions and cold reload in private SDL processes.

Requires an existing WITH_CAB_VIEW build, SDL offscreen and installed OpenGFX.
The supplied disposable WP11 save is copied, never edited. No build, download,
owner display, federation connection or human UAT is part of this proof.
"""
import argparse
import hashlib
import json
import os
import platform
from pathlib import Path
import resource
import shutil
import subprocess
import time

from PIL import Image, ImageChops

from test_commonwealth_platform_art import ROOT, configuration, profile_environment


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def no_core_dump():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def validate_profiles(manifest, phase, rotation):
    """Reject incomplete or adaptive data before treating a profiling run as evidence."""
    labels = {"back_approach", "back_near_approach", "back_transit", "back_arrival_mixed"}
    if phase == "roundtrip":
        labels |= {"out_approach", "out_near_approach", "out_transit", "out_arrival_mixed"}
    expected = {(label, width, height, mode) for label in labels
                for width, height in ((480, 272), (640, 372))
                for mode in ("off", "reduced", "full")}
    found = set()
    mode_groups = {}
    errors = []
    for cell in manifest.get("profiles", []):
        key = (cell.get("capture_label"), cell.get("view_width"), cell.get("view_height"), cell.get("mode"))
        if key not in expected or key in found:
            errors.append(f"Unexpected or duplicate cell: {key}")
            continue
        found.add(key)
        mode_groups.setdefault(key[:3], []).append(cell)
        if type(cell.get("effect_elapsed_ms")) is not int or cell["effect_elapsed_ms"] < 0 or cell.get("mode_rotation") != rotation:
            errors.append(f"Missing immutable effect descriptor or mode rotation: {key}")
        if key[3] in ("off", "reduced") and cell.get("effect_elapsed_ms") != 0:
            errors.append(f"Static mode has an animated descriptor: {key}")
        if cell.get("warmup_count") != 20 or cell.get("sample_count") != 100 or len(cell.get("samples", [])) != 100:
            errors.append(f"Incorrect warmup/sample count: {key}")
        transit = key[0].endswith("transit")
        if cell.get("phase") != ("transit" if transit else "scene") or not isinstance(cell.get("pose"), dict):
            errors.append(f"Missing or incorrect phase/pose: {key}")
        if cell.get("frozen_state_unchanged") is not True or not isinstance(cell.get("frozen_snapshot"), dict):
            errors.append(f"Missing frozen-state proof: {key}")
        if key[0].endswith("near_approach"):
            gate = cell.get("gate", {})
            if not 0 < gate.get("signed_face_distance", 999) <= 16 or not 0 <= gate.get("lateral_offset", 999) <= 8 or gate.get("world") != cell.get("selected_world"):
                errors.append(f"Near approach is outside the validated entrance band: {key}")
        for sample in [cell.get("cold_sample", {})] + cell.get("samples", []):
            wall = sample.get("external_total_us")
            if type(wall) is not int or wall < 0:
                errors.append(f"Invalid wall time: {key}")
                break
            frame = sample.get("renderer")
            if transit:
                if frame is not None or sample.get("scene_geometry", "missing") is not None or cell.get("cache") is not None:
                    errors.append(f"Transit includes scene data: {key}")
                    break
                if any(type(sample.get(field)) is not int or sample[field] < 0 for field in ("effect_us", "total_us")) or (key[3] == "off" and sample["effect_us"] != 0):
                    errors.append(f"Missing or invalid transit effect timing: {key}")
                    break
                continue
            if not isinstance(frame, dict) or not frame.get("rendered") or frame.get("cache_hit") or frame.get("scale") != 1.0:
                errors.append(f"Missing full-size render: {key}")
                break
            if (frame.get("internal_width"), frame.get("internal_height")) != key[1:3] or (frame.get("view_width"), frame.get("view_height")) != key[1:3]:
                errors.append(f"Different frame dimensions: {key}")
                break
            fields = ("prepare_us", "raster_us", "effect_us", "output_us", "total_us", "visible_tiles", "triangles", "threads")
            if any(type(frame.get(field)) is not int or frame[field] < 0 for field in fields):
                errors.append(f"Missing/negative renderer measurements: {key}")
                break
            if key[3] == "off" and frame["effect_us"] != 0:
                errors.append(f"Off mode unexpectedly includes effect work: {key}")
                break
        if not transit and not isinstance(cell.get("cache"), dict):
            errors.append(f"Missing cache accounting: {key}")
        if not transit:
            effect_bytes = cell.get("cache", {}).get("effect_scratch_capacity_bytes")
            if type(effect_bytes) is not int or not 0 <= effect_bytes <= 8 * key[1] * key[2] + 256 * 1024 or (key[3] == "off" and effect_bytes != 0):
                errors.append(f"Missing/excessive effect storage: {key}")
            cached = cell.get("cached_sample", {}).get("renderer", {})
            if not cached.get("cache_hit") or cached.get("rendered") or any(cached.get(field) != 0 for field in ("prepare_us", "raster_us", "effect_us", "threads")):
                errors.append(f"Missing/invalid cached-output sample: {key}")
    order = ["off", "reduced", "full"]
    order = order[rotation:] + order[:rotation]
    for key, cells in mode_groups.items():
        if [cell.get("mode") for cell in cells] != order:
            errors.append(f"Incorrect rotated mode order: {key}")
        first = cells[0]
        for cell in cells[1:]:
            if any(cell.get(field) != first.get(field) for field in ("pose", "selected_world", "frozen_snapshot")):
                errors.append(f"Modes measured different game/camera states: {key}")
        if first.get("phase") == "scene":
            geometry = lambda cell: [(s.get("renderer", {}).get("visible_tiles"), s.get("renderer", {}).get("triangles")) for s in cell.get("samples", [])]
            if any(geometry(cell) != geometry(first) for cell in cells[1:]):
                errors.append(f"Effects changed scene geometry: {key}")
    if found != expected:
        errors.append(f"Missing cells: {sorted(expected - found)}")
    return {"passed": not errors, "expected_cells": len(expected), "observed_cells": len(found), "errors": errors}


def compare_normal_viewport(output, phase):
    names = [f"gate_{phase}_normal_before_reopen.png",
             f"gate_{phase}_normal_after_reopen_close.png"]
    result = {"passed": False, "screenshots": names,
              "region_reason": "Main viewport below the 22-pixel toolbar; same paused endpoint and scroll position."}
    try:
        with Image.open(output / names[0]) as first, Image.open(output / names[1]) as second:
            if first.size != second.size or first.width != 1280 or first.height != 800:
                result["error"] = "Unexpected or different native screenshot dimensions"
                return result
            region = (0, 22, first.width, first.height)
            difference = ImageChops.difference(first.convert("RGB").crop(region),
                                              second.convert("RGB").crop(region))
            result["region"] = region
            result["difference_bbox_in_region"] = difference.getbbox()
            result["changed_pixels"] = sum(pixel != (0, 0, 0) for pixel in difference.getdata())
            result["passed"] = result["changed_pixels"] == 0
    except (OSError, ValueError) as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def compare_effect_pixels(output, phase, manifest, baseline_root):
    labels = ["back_near_approach", "back_transit", "back_arrival_mixed"]
    if phase == "roundtrip":
        labels = ["out_near_approach", "out_transit", "out_arrival_mixed"] + labels
    rect = manifest.get("cab_view_rect", {})
    expected_rect = {"left": 0, "top": 38, "right": 479, "bottom": 307,
                     "width": 480, "height": 270}
    if rect != expected_rect:
        return {"passed": False, "error": "Missing or unexpected live cab widget rectangle",
                "observed_rect": rect, "expected_rect": expected_rect}
    # Native Rect endpoints are inclusive; Pillow's right/bottom are exclusive.
    # The next row belongs to the controls, including the new Effects button.
    region = (rect["left"], rect["top"], rect["right"] + 1, rect["bottom"] + 1)
    result = {"passed": True, "cab_view_region": region, "comparisons": [],
              "timing_scope": "80/160 labels denote injected GUI callback deltas during a naturally observed paused phase; native UI callbacks may also occur. Simulation state remains frozen."}
    captures = manifest.get("effect_captures", [])
    if sorted(c.get("label") for c in captures) != sorted(labels) or any(c.get("frozen_state_unchanged") is not True for c in captures):
        result.update(passed=False, error="Missing complete frozen effect capture sequences")
    baseline = baseline_root / phase
    for label in labels:
        prefix = f"gate_{phase}_{label}"
        pairs = [("full_motion_0_80", output / f"{prefix}.png", output / f"{prefix}_full_80.png", False),
                 ("full_motion_80_160", output / f"{prefix}_full_80.png", output / f"{prefix}_full_160.png", False),
                 ("full_visible", output / f"{prefix}_full_80.png", output / f"{prefix}_off.png", False),
                 ("reduced_static", output / f"{prefix}_reduced_0.png", output / f"{prefix}_reduced_80.png", True),
                 ("off_stable", output / f"{prefix}_off.png", output / f"{prefix}_off_again.png", True),
                 ("off_baseline_exact", output / f"{prefix}_off.png", baseline / f"{prefix}.png", True)]
        for check, first, second, expect_equal in pairs:
            comparison = {"label": label, "check": check, "files": [str(first), str(second)], "passed": False}
            try:
                with Image.open(first) as a, Image.open(second) as b:
                    if a.size != (1280, 800) or b.size != a.size:
                        raise ValueError("Unexpected or unequal native screenshot dimensions")
                    difference = ImageChops.difference(a.convert("RGB").crop(region), b.convert("RGB").crop(region))
                    changed = sum(pixel != (0, 0, 0) for pixel in difference.getdata())
                    comparison.update(changed_pixels=changed, passed=(changed == 0) == expect_equal)
            except (OSError, ValueError) as exc:
                comparison["error"] = f"{type(exc).__name__}: {exc}"
            if not check.startswith("full_motion_"):
                result["passed"] = result["passed"] and comparison["passed"]
            result["comparisons"].append(comparison)
        motion = [c for c in result["comparisons"] if c["label"] == label and c["check"].startswith("full_motion_")]
        # A sinusoid can produce equal adjacent samples around its turning point.
        # Require visible motion across the three observed frames, and retain both differences.
        result["passed"] = result["passed"] and all("error" not in c for c in motion) and any(c["passed"] for c in motion)
    return result


def run_phase(binary, source, output, phase, baseline, expected=None, profile=False, profile_rotation=0):
    output.mkdir(parents=True, exist_ok=False)
    save = output / "fixture-copy.sav"
    shutil.copyfile(source, save)
    config = configuration(output)
    config.write_text(config.read_text().replace("[gui]\n", "[gui]\nerrmsg_duration = 0\n"))
    (output / "scripts").mkdir()
    (output / "scripts/game_start.scr").write_text("cab_gate_native_start\n")
    env = {**os.environ, **profile_environment(output), "SDL_VIDEODRIVER": "offscreen",
           "SDL_RENDER_DRIVER": "software", "OPENSPACETTD_WORLD_COUNT": "3",
           "OSTTD_CAB_NATIVE_CONFIG": str(config), "OSTTD_CAB_NATIVE_SAVE": str(save),
           "OSTTD_CAB_NATIVE_OUTPUT": str(output), "OSTTD_CAB_NATIVE_BINARY": str(binary),
           "OSTTD_CAB_GATE_PHASE": phase}
    for key in ("DISPLAY", "WAYLAND_DISPLAY", "OSTTD_CAB_GATE_EXPECTED", "OSTTD_CAB_PROFILE", "OSTTD_CAB_PROFILE_ROTATION"):
        env.pop(key, None)
    if profile:
        env["OSTTD_CAB_PROFILE"] = "1"
        env["OSTTD_CAB_PROFILE_ROTATION"] = str(profile_rotation)
    if expected is not None:
        env["OSTTD_CAB_GATE_EXPECTED"] = str(expected)
    baseset = Path(env["XDG_DATA_HOME"]) / "openttd/baseset"
    if baseset.is_symlink():
        baseset.unlink()  # Only this run's newly created profile symlink.
    baseset.mkdir(exist_ok=True)
    installed = Path("/usr/share/games/openttd/baseset/opengfx")
    if not installed.is_dir():
        raise RuntimeError("Installed OpenGFX unavailable; no download attempted")
    (baseset / "opengfx").symlink_to(installed, target_is_directory=True)
    command = [str(binary), "Native SDL local gate cab round trip and cold reload"]
    report = {"passed": False, "phase": phase, "command": command,
              "source_save": str(source), "source_save_sha256": sha256(source),
              "binary_sha256": sha256(binary), "config_sha256": sha256(config),
              "display": "SDL offscreen / software", "human_uat": "Pending", "profiling_requested": profile,
              "profile_rotation": profile_rotation,
              "hard_timeout_seconds": 240, "minimum_free_bytes": 100 * 1024 * 1024,
              "content_sha256": {str(p): sha256(p) for p in sorted(installed.iterdir()) if p.is_file()},
              "newgrf_sha256": {str(p): sha256(p) for p in sorted((ROOT / "bin/newgrf").glob("*.grf"))}}
    if profile:
        cpu_lines = Path("/proc/cpuinfo").read_text().splitlines()
        report["machine"] = {"platform": platform.platform(), "logical_cpus": os.cpu_count(),
                             "cpu_model": next((line.split(":", 1)[1].strip() for line in cpu_lines
                                                if line.startswith("model name")), "unavailable")}
        report["sampled_process_memory_kib"] = {"rss": 0, "high_water": 0,
            "scope": "Maximum observed /proc process RSS and high-water, sampled every 100ms; final unsampled allocations may be absent."}
    started = time.monotonic()
    with (output / "native-process.log").open("x") as log:
        process = subprocess.Popen(command, cwd=output, env=env, stdin=subprocess.DEVNULL,
                                   stdout=log, stderr=subprocess.STDOUT, preexec_fn=no_core_dump)
        try:
            while process.poll() is None:
                if profile:
                    try:
                        lines = Path(f"/proc/{process.pid}/status").read_text().splitlines()
                        values = {line.split(":", 1)[0]: int(line.split()[1]) for line in lines
                                  if line.startswith(("VmRSS:", "VmHWM:"))}
                        memory = report["sampled_process_memory_kib"]
                        memory["rss"] = max(memory["rss"], values.get("VmRSS", 0))
                        memory["high_water"] = max(memory["high_water"], values.get("VmHWM", 0))
                    except (OSError, ValueError):
                        pass
                if time.monotonic() - started > 240:
                    report["error"] = "Native process exceeded 240-second hard stop"
                    process.kill()
                    break
                if shutil.disk_usage(output).free < report["minimum_free_bytes"]:
                    report["error"] = "Stopped own native process below 100 MiB free disk reserve"
                    process.kill()
                    break
                time.sleep(0.1)
            process.wait()
            report["exit_code"] = process.returncode
            manifest = output / "gate-native-manifest.json"
            if manifest.is_file():
                report["native_manifest"] = json.loads(manifest.read_text())
            report["passed"] = process.returncode == 0 and report.get("native_manifest", {}).get("passed") is True
            calls = report.get("native_manifest", {}).get("explicit_state_game_loop_calls")
            report["explicit_call_limit"] = 16384 if phase == "roundtrip" else 8192
            report["explicit_call_budget_valid"] = (type(calls) is int and
                                                    0 < calls <= report["explicit_call_limit"])
            report["passed"] = report["passed"] and report["explicit_call_budget_valid"]
            report["normal_viewport_comparison"] = compare_normal_viewport(output, phase)
            report["passed"] = report["passed"] and report["normal_viewport_comparison"]["passed"]
            report["effect_pixel_comparisons"] = compare_effect_pixels(output, phase, report.get("native_manifest", {}), baseline)
            report["passed"] = report["passed"] and report["effect_pixel_comparisons"]["passed"]
            if profile:
                report["profile_validation"] = validate_profiles(report.get("native_manifest", {}), phase, profile_rotation)
                report["passed"] = report["passed"] and report["profile_validation"]["passed"]
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
            report["elapsed_seconds"] = time.monotonic() - started
            report["source_save_unchanged"] = sha256(source) == report["source_save_sha256"]
            report["copy_sha256_after"] = sha256(save)
            report["screenshots"] = {p.name: {"bytes": p.stat().st_size, "sha256": sha256(p)} for p in sorted(output.glob("*.png"))}
            report["passed"] = report["passed"] and report["source_save_unchanged"]
            (output / "runner-evidence.json").write_text(json.dumps(report, indent=2) + "\n")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--save", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path, help="New evidence directory")
    parser.add_argument("--test-binary", type=Path, default=ROOT / "build/openttd_test")
    parser.add_argument("--profile", action="store_true", help="Measure naturally paused gate phases without simulation advancement")
    parser.add_argument("--profile-rotation", type=int, choices=(0, 1, 2), default=0,
                        help="Rotate Off/Reduced/Full measurement order across fresh-process repeats")
    parser.add_argument("--baseline", type=Path, default=ROOT / "build/cab-stage3-baseline/near-repeat-01",
                        help="Preserved pre-effect native images, containing roundtrip and cold directories")
    args = parser.parse_args()
    source = args.save.resolve(strict=True)
    binary = args.test_binary.resolve(strict=True)
    baseline = args.baseline.resolve(strict=True)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    report = {"passed": False, "phases": [], "source_save_sha256": sha256(source)}
    try:
        first = run_phase(binary, source, output / "roundtrip", "roundtrip", baseline, profile=args.profile, profile_rotation=args.profile_rotation)
        report["phases"].append(first)
        if not first["passed"]:
            raise RuntimeError("Initial native round trip failed; cold phase not started")
        checkpoint = output / "roundtrip/gate-checkpoint.sav"
        expected = output / "roundtrip/gate-checkpoint.json"
        if not checkpoint.is_file() or not expected.is_file():
            raise RuntimeError("Initial proof omitted its native save or frozen comparison snapshot")
        report["checkpoint_sha256"] = sha256(checkpoint)
        report["expected_snapshot_sha256"] = sha256(expected)
        cold = run_phase(binary, checkpoint, output / "cold", "cold", baseline, expected, profile=args.profile, profile_rotation=args.profile_rotation)
        report["phases"].append(cold)
        report["explicit_state_game_loop_calls"] = sum(
            p.get("native_manifest", {}).get("explicit_state_game_loop_calls", 0)
            for p in report["phases"])
        report["combined_explicit_call_limit"] = 24576
        report["passed"] = cold["passed"] and report["explicit_state_game_loop_calls"] <= 24576
    except (RuntimeError, OSError, ValueError) as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        report["source_save_unchanged"] = sha256(source) == report["source_save_sha256"]
        report["passed"] = report["passed"] and report["source_save_unchanged"]
        (output / "gate-runner-evidence.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"passed": report["passed"], "completed_phases": len(report["phases"]),
                      "source_save_unchanged": report["source_save_unchanged"], "error": report.get("error")}))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
